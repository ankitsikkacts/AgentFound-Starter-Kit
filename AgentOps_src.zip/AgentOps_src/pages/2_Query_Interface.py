import streamlit as st
import requests
import sys
import os

# Add the parent directory to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from auth import login_widget, check_access

# Constants
BASE_URL = "http://127.0.0.1:5000/call_agentOps_agent"  # Replace with your actual FastAPI endpoint
HEADERS = {"Content-Type": "application/json"}

# Authentication check
if not login_widget():
    st.warning("Please login to access the interface")
    st.stop()

# Only admin can access Query Interface
if not check_access(required_role="admin"):
    st.error("You don't have permission to access this interface. Admin role required.")
    st.stop()



# Streamlit UI
st.markdown("<h1 style='font-size: 2.25em;'>Agent Foundry - AgentOps - Query</h1>", unsafe_allow_html=True)


# Input box
query = st.text_input("Enter your query:")

# Submit button
if st.button("Submit"):
    if query.strip():
        # Clear previous output
        st.empty()

        # Show loading spinner
        with st.spinner("Waiting for response..."):
            data = {"query": query}
            try:
                response = requests.post(BASE_URL, headers=HEADERS, json=data)
                if response.status_code == 200:
                    result = response.json()
                    st.success("Response received:")
                    st.write(result)
                else:
                    st.error(f"Error {response.status_code}: {response.text}")
            except Exception as e:
                st.error(f"Request failed: {e}")
    else:
        st.warning("Please enter a query before submitting.")