import streamlit as st
import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import boto3
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from pymongo import MongoClient
from bson.objectid import ObjectId
import pytz
import logging
import os
import traceback
import uuid

# Create logs directory if it doesn't exist
os.makedirs("logs", exist_ok=True)

# Configure logging with rotating file handler
log_filename = f"logs/agent_ops_dashboard_{datetime.now().strftime('%Y%m%d')}.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler()
    ]
)

# Create a custom logger for the application
logger = logging.getLogger("agent_ops_dashboard")
logger.setLevel(logging.DEBUG)  # Set to DEBUG to capture all levels of logs

# Generate a unique session ID for correlation
session_id = str(uuid.uuid4())[:8]
logger.info(f"Application started - Session ID: {session_id}")

# Set page title and layout
st.set_page_config(page_title="Agent Ops Dashboard", layout="wide")

BASE_URL = "http://127.0.0.1:5000/call_agentOps_agent"
HEADERS = {"Content-Type": "application/json"}

# MongoDB configuration
MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "bedrock_analytics"

logger.info(f"Configured MongoDB connection to {MONGO_URI}, database: {DB_NAME}")

# Custom CSS
st.markdown("""
    <style>
        .stApp {
            background: linear-gradient(to right, #000080, #ff7f50);
            background-attachment: fixed;
        }

        /* Target the Fetch Logs button with its specific attributes */
button[kind="secondary"][data-testid="stBaseButton-secondary"] {
    background-color: #ff0000 !important;
    color: white !important;
    border: none !important;
}

/* Target the text container inside the button */
button[kind="secondary"][data-testid="stBaseButton-secondary"] .st-emotion-cache-rxbcmk p {
    color: white !important;
}

/* Fix hover state */
button[kind="secondary"][data-testid="stBaseButton-secondary"]:hover {
    background-color: #cc0000 !important;
    color: white !important;
}

/* Target the specific emotion-cache class */
.st-emotion-cache-1rwb540 {
    background-color: #ff0000 !important;
    color: white !important;
}

/* Ensure the download button also gets styled */
div.stDownloadButton button {
    background-color: #ff0000 !important;
    color: white !important;
}
        /* More specific selectors for the buttons */
        button[kind="secondary"], 
        div.stDownloadButton button,
        button[data-testid="StyledFullScreenButton"] {
            background-color: #ff0000 !important;
            color: white !important;
            border-color: transparent !important;
        }

        /* Fix hover states */
        button[kind="secondary"]:hover, 
        div.stDownloadButton button:hover,
        button[data-testid="StyledFullScreenButton"]:hover {
            background-color: #cc0000 !important;
            color: white !important;
        }

        /* Target buttons by their contained text */
        button:has(div:contains("Fetch Logs")), 
        button:has(div:contains("Download Full Logs")) {
            background-color: #ff0000 !important;
            color: white !important;
        }

        /* Additional styling for the fullscreen button */
        [data-testid="StyledFullScreenButton"] {
            background-color: #ff0000 !important;
            fill: white !important;
        }

        /* Override any Streamlit defaults with !important flags */
        .stButton button {
            background-color: #ff0000 !important;
            color: white !important;
        }
        .white-text {
            color: white !important;
        }

        .metric-box {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            text-align: center;
            margin-bottom: 20px;
        }

        .metric-label, .metric-value {
            color: white !important;
        }
        
        .logs-container {
            background-color: rgba(0, 0, 0, 0.2);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        
        .tab-header {
            color: white !important;
            font-size: 1.5em;
            margin-bottom: 15px;
        } 
        
        .alert-header {
            font-size: 16px !important;
            color: white;
        }
        
        div[data-testid="stDataFrame"] div {
            font-size: 10px !important;
        }
        
        /* Make all slider text white */
        div[data-testid="stSlider"] label {
            color: white !important;
        }
        
        /* Make number inputs white text */
        div[data-testid="stNumberInput"] label {
            color: white !important;
        }
        
        /* Make radio buttons white */
        div[data-testid="stRadio"] label {
            color: white !important;
        }
        
        /* Make checkboxes white */
        div[data-testid="stCheckbox"] label {
            color: white !important;
        }
        
        /* Make selectbox text white */
        div[data-testid="stSelectbox"] label {
            color: white !important;
        }
        
        /* All input labels white */
        .stTextInput > label, .stTextArea > label {
            color: white !important;
        }
        
        /* Info, success, error box text */
        div[data-testid="stInfo"], div[data-testid="stSuccess"], div[data-testid="stWarning"] {
            color: white !important;
        }
        
        /* Metric text in white */
        [data-testid="stMetricValue"] {
            color: white !important;
        }
        
        [data-testid="stMetricLabel"] {
            color: white !important;
        }
        
        /* Expander text in white */
        [data-testid="stExpander"] {
            color: white !important;
        }
        
        /* All buttons text */
        button {
            color: white !important;
        }
        
        .stTabs [data-baseweb="tab-list"] {
            gap: 24px;
        }
        
        .stTabs [data-baseweb="tab"] {
            background-color: rgba(255,255,255,0.1);
            padding: 10px 20px;
            border-radius: 4px;
            color: white;
        }
        
        .stTabs [aria-selected="true"] {
            background-color: rgba(255,255,255,0.2);
            border-bottom: 2px solid white;
        }
        
        /* Log viewer styles */
        .log-viewer {
            background-color: #1e1e1e;
            color: #dcdcdc;
            font-family: 'Courier New', monospace;
            padding: 10px;
            border-radius: 5px;
            height: 400px;
            overflow: auto;
            white-space: pre-wrap;
        }
        
        .log-error {
            color: #ff6b6b;
        }
        
        .log-warning {
            color: #ffd93d;
        }
        
        .log-info {
            color: #4cd4ff;
        }
        
        .log-debug {
            color: #98c379;
        }
    </style>
""", unsafe_allow_html=True)

# MongoDB utility functions
def connect_to_mongodb():
    """Connect to MongoDB and return client"""
    try:
        logger.info(f"[MongoDB] Connecting to {MONGO_URI}")
        client = MongoClient(MONGO_URI)
        # Test the connection
        client.server_info()
        logger.info("[MongoDB] Connection successful")
        return client
    except Exception as e:
        logger.error(f"[MongoDB] Connection error: {str(e)}")
        logger.debug(f"[MongoDB] Connection error details: {traceback.format_exc()}")
        st.error(f"Could not connect to MongoDB")
        return None

def analyze_bedrock_costs(collection_name, db_name=DB_NAME):
    """
    Calculate bedrock costs from MongoDB collection
    Returns: daily cost data, lifetime cost, and total tokens
    """
    function_logger = logging.getLogger("agent_ops_dashboard.analyze_bedrock_costs")
    function_logger.info(f"Analyzing Bedrock costs for collection: {collection_name}")
    
    client = connect_to_mongodb()
    if not client:
        return [], 0, 0, 0
    
    db = client[db_name]
    
    # Check if collection exists
    if collection_name not in db.list_collection_names():
        function_logger.warning(f"Collection '{collection_name}' not found in database")
        return [], 0, 0, 0
    
    collection = db[collection_name]
    
    # Pricing per 1M tokens (adjustment based on standard pricing)
    pricing = {
        'claude-3-sonnet': {'input': 3.0, 'output': 15.0},  # per million tokens
        'claude-3-haiku': {'input': 0.25, 'output': 1.25},  # per million tokens
        'titan-text': {'input': 0.8, 'output': 1.6},        # per million tokens
        'default': {'input': 3.0, 'output': 15.0}           # per million tokens - using Claude-3-Sonnet pricing as default
    }
    
    # Get all documents to calculate lifetime costs
    all_documents = list(collection.find())
    function_logger.info(f"Total documents found: {len(all_documents)}")
    
    # Process each document to extract token counts correctly
    daily_costs = {}
    lifetime_input_tokens = 0
    lifetime_output_tokens = 0
    lifetime_invocations = 0
    
    for doc in all_documents:
        # Extract date from timestamp
        try:
            if 'timestamp' in doc:
                timestamp = doc['timestamp']
                if isinstance(timestamp, str):
                    # Handle ISO format timestamp
                    if timestamp.endswith('Z'):
                        timestamp = timestamp.replace('Z', '+00:00')
                    date_obj = datetime.fromisoformat(timestamp)
                    date_str = date_obj.strftime("%Y-%m-%d")
                else:
                    # Handle other timestamp formats
                    date_str = "unknown-date"
            else:
                date_str = "unknown-date"
                
            # Initialize date in daily_costs if not exists
            if date_str not in daily_costs:
                daily_costs[date_str] = {
                    'date': date_str,
                    'input_tokens': 0,
                    'output_tokens': 0,
                    'invocations': 0,
                    'models': set()
                }
                
            # Extract token counts - try all possible field locations
            input_tokens = 0
            output_tokens = 0
            
            # Direct fields at the root level
            if 'input_tokens' in doc:
                input_tokens = doc['input_tokens']
            elif 'inputTokens' in doc:
                input_tokens = doc['inputTokens']
                
            if 'output_tokens' in doc:
                output_tokens = doc['output_tokens']
            elif 'outputTokens' in doc:
                output_tokens = doc['outputTokens']
            
            # Look in nested fields
            if input_tokens == 0 or output_tokens == 0:
                # Try to extract from parsed_data or raw_message
                if 'parsed_data' in doc and isinstance(doc['parsed_data'], dict):
                    parsed = doc['parsed_data']
                    if 'input' in parsed and isinstance(parsed['input'], dict):
                        input_tokens = parsed['input'].get('inputTokenCount', input_tokens)
                    if 'output' in parsed and isinstance(parsed['output'], dict):
                        output_tokens = parsed['output'].get('outputTokenCount', output_tokens)
                
                # Check if tokens are in nested input/output objects
                if 'input' in doc and isinstance(doc['input'], dict):
                    input_tokens = doc['input'].get('inputTokenCount', input_tokens)
                if 'output' in doc and isinstance(doc['output'], dict):
                    output_tokens = doc['output'].get('outputTokenCount', output_tokens)
                    
                # Try to extract from output.outputBodyJson.usage
                if 'output' in doc and isinstance(doc['output'], dict):
                    if 'outputBodyJson' in doc['output']:
                        output_body = doc['output']['outputBodyJson']
                        if isinstance(output_body, str):
                            try:
                                output_body = json.loads(output_body)
                            except:
                                pass
                        
                        if isinstance(output_body, dict) and 'usage' in output_body:
                            input_tokens = output_body['usage'].get('input_tokens', input_tokens)
                            output_tokens = output_body['usage'].get('output_tokens', output_tokens)
            
            # Extract model information
            model = None
            if 'model_id' in doc:
                model = doc['model_id']
            elif 'modelId' in doc:
                model = doc['modelId']
            
            # Update daily counts
            daily_costs[date_str]['input_tokens'] += input_tokens
            daily_costs[date_str]['output_tokens'] += output_tokens
            daily_costs[date_str]['invocations'] += 1
            if model:
                daily_costs[date_str]['models'].add(model)
            
            # Update lifetime counts
            lifetime_input_tokens += input_tokens
            lifetime_output_tokens += output_tokens
            lifetime_invocations += 1
            
        except Exception as e:
            function_logger.error(f"Error processing document: {e}")
            function_logger.debug(f"Problematic document: {str(doc)[:200]}...")
            continue
    
    # Calculate costs for each day
    seven_days_ago = (datetime.utcnow() - timedelta(days=7)).strftime("%Y-%m-%d")
    results = []
    cumulative_cost = 0
    
    # Sort dates
    sorted_dates = sorted(daily_costs.keys())
    
    for date_str in sorted_dates:
        day_data = daily_costs[date_str]
        
        # Calculate cost for this day
        input_cost = 0
        output_cost = 0
        
        # If we have models, use their pricing; otherwise use default
        if day_data['models']:
            for model in day_data['models']:
                model_key = next((k for k in pricing.keys() if k in str(model).lower()), 'default')
                input_cost += (day_data['input_tokens'] / 1_000_000) * pricing[model_key]['input']
                output_cost += (day_data['output_tokens'] / 1_000_000) * pricing[model_key]['output']
            
            # Average the cost if multiple models
            input_cost /= len(day_data['models'])
            output_cost /= len(day_data['models'])
        else:
            # Use default pricing if no model info
            input_cost = (day_data['input_tokens'] / 1_000_000) * pricing['default']['input']
            output_cost = (day_data['output_tokens'] / 1_000_000) * pricing['default']['output']
        
        daily_cost = input_cost + output_cost
        cumulative_cost += daily_cost
        
        # Create result entry with cumulative cost
        result_entry = {
            'date': date_str,
            'input_tokens': day_data['input_tokens'],
            'output_tokens': day_data['output_tokens'],
            'total_tokens': day_data['input_tokens'] + day_data['output_tokens'],
            'invocations': day_data['invocations'],
            'daily_cost': round(daily_cost, 4),
            'cumulative_cost': round(cumulative_cost, 4)
        }
        
        # Only include in results if it's within the last 7 days
        if date_str >= seven_days_ago:
            results.append(result_entry)
    
    # Calculate lifetime cost
    lifetime_cost = 0
    
    # Default to the default pricing model for lifetime cost calculation
    input_cost = (lifetime_input_tokens / 1_000_000) * pricing['default']['input']
    output_cost = (lifetime_output_tokens / 1_000_000) * pricing['default']['output']
    lifetime_cost = input_cost + output_cost
    
    total_tokens = lifetime_input_tokens + lifetime_output_tokens
    
    function_logger.info(f"Analysis complete - Lifetime cost: ${lifetime_cost:.2f}, " +
                      f"Total tokens: {total_tokens:,}, Total invocations: {lifetime_invocations:,}")
    
    return results, round(lifetime_cost, 4), total_tokens, lifetime_invocations

def get_agent_logs(arn_id, days=7):
    """Retrieve logs for a specific agent from MongoDB"""
    function_logger = logging.getLogger("agent_ops_dashboard.get_agent_logs")
    try:
        function_logger.info(f"Retrieving logs for agent '{arn_id}' for past {days} days")
        client = connect_to_mongodb()
        if not client:
            function_logger.warning("MongoDB client is None, returning empty logs")
            return []
        
        db = client[DB_NAME]
        collection_name = f"bedrock_logs_{arn_id}"
        
        # Check if collection exists
        if collection_name not in db.list_collection_names():
            function_logger.warning(f"Collection '{collection_name}' not found in database")
            return []
        
        collection = db[collection_name]
        
        # Calculate date range for the past 7 days
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Query logs within date range - using ISO format date comparison
        start_date_str = start_date.isoformat()
        function_logger.debug(f"Querying logs since {start_date_str}")
        
        logs = list(collection.find({"timestamp": {"\$gte": start_date_str}}))
        function_logger.info(f"Retrieved {len(logs)} logs for agent '{arn_id}'")
        
        return logs
    except Exception as e:
        function_logger.error(f"Error retrieving logs from MongoDB: {str(e)}")
        function_logger.error(f"Error details: {traceback.format_exc()}")
        st.error(f"Error retrieving logs from MongoDB")
        return []

def calculate_daily_costs_from_mongo(arn_id):
    """
    Process MongoDB logs to calculate daily and cumulative costs using analyze_bedrock_costs
    Returns a DataFrame with date and cumulative cost
    """
    function_logger = logging.getLogger("agent_ops_dashboard.calculate_daily_costs")
    function_logger.info(f"Calculating daily costs for agent: {arn_id}")
    
    collection_name = f"bedrock_logs_{arn_id}"
    
    # Get cost data
    cost_data, lifetime_cost, total_tokens, total_invocations = analyze_bedrock_costs(collection_name)
    
    if not cost_data:
        function_logger.warning(f"No cost data found for {collection_name}")
        # Return empty DataFrame with expected columns
        return pd.DataFrame({"Date": [], "Daily Cost (USD)": [], "Cost (USD)": []}), 0, 0, 0
    
    # Convert to DataFrame
    df = pd.DataFrame(cost_data)
    
    # Rename columns to match expected format
    if not df.empty:
        df = df.rename(columns={
            'date': 'Date',
            'daily_cost': 'Daily Cost (USD)',
            'cumulative_cost': 'Cost (USD)'
        })
    
    # Make sure we have entries for all days in the last 7 days
    today = datetime.now().date()
    last_7_days = [today - timedelta(days=i) for i in range(6, -1, -1)]
    
    # Create a template DataFrame with all 7 days
    template_df = pd.DataFrame({"Date": [d.strftime("%Y-%m-%d") for d in last_7_days]})
    
    # Merge with actual data, filling missing days with 0
    if not df.empty:
        df = pd.merge(template_df, df, on="Date", how="left").fillna(0)
    else:
        df = template_df
        df["Daily Cost (USD)"] = 0
        df["Cost (USD)"] = 0
    
    # Sort by date
    df = df.sort_values("Date")
    
    # Format dates to show as 'Mon DD'
    df["Date"] = df["Date"].apply(lambda x: datetime.strptime(x, "%Y-%m-%d").strftime('%b %d'))
    
    function_logger.info(f"Generated cost data for {len(df)} days, " +
                       f"total cumulative cost: \${df['Cost (USD)'].iloc[-1] if not df.empty else 0:.2f}")
    
    return df, lifetime_cost, total_tokens, total_invocations

# Utility functions for AWS config
def read_aws_config(config_name="config_server"):
    """Read AWS credentials from JSON config file"""
    function_logger = logging.getLogger("agent_ops_dashboard.read_aws_config")
    try:
        import os
        # Determine the config file path
        config_file = f"{config_name}.json"
        current_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(current_dir, config_file)
        
        function_logger.info(f"Reading AWS config from {config_path}")
        
        # Check if file exists
        if not os.path.exists(config_path):
            function_logger.error(f"Config file not found: {config_file}")
            st.error(f"Config file not found: {config_file}")
            return None
        
        # Read and parse the JSON config
        with open(config_path, 'r') as f:
            config_data = json.load(f)
            
        function_logger.info(f"Successfully loaded AWS config")
        function_logger.debug(f"AWS config region: {config_data.get('region_name', 'default')}")
        
        return config_data
        
    except Exception as e:
        function_logger.error(f"Error reading config file {config_name}: {str(e)}")
        function_logger.debug(f"Error details: {traceback.format_exc()}")
        st.error(f"Error reading config file {config_name}")
        return None

# Fetch agent counts and metadata
def fetch_counts_and_metadata():
    function_logger = logging.getLogger("agent_ops_dashboard.fetch_counts_and_metadata")
    function_logger.info("Fetching agent counts and metadata")
    
    try:
        # Fetch active agents
        data_active = {"query": "provide the count of active agents"}
        function_logger.debug(f"Sending request to {BASE_URL} for active agents")
        response_active = requests.post(BASE_URL, headers=HEADERS, json=data_active)
        
        if response_active.status_code != 200:
            function_logger.error(f"API call failed with status code {response_active.status_code}")
            function_logger.debug(f"Response content: {response_active.text[:200]}")
            return "Error", "Error", [], {}
            
        active_agents = response_active.json().get("total_active_agents", "N/A")
        agents = response_active.json().get("active_agents", [])
        function_logger.info(f"Retrieved {active_agents} active agents")

        # Process agent names and metadata
        agent_names = sorted([agent["name"] for agent in agents])
        agent_metadata = {agent["name"]: agent for agent in agents}
        function_logger.debug(f"Agent names: {agent_names}")

        # Fetch all registered agents
        data_all = {"query": "provide the count of registered agents"}
        function_logger.debug(f"Sending request to {BASE_URL} for all agents")
        response_all = requests.post(BASE_URL, headers=HEADERS, json=data_all)
        
        if response_all.status_code != 200:
            function_logger.error(f"API call failed with status code {response_all.status_code}")
            return "Error", active_agents, agent_names, agent_metadata
            
        all_agents = response_all.json().get("total_agents", "N/A")
        function_logger.info(f"Retrieved {all_agents} total registered agents")

        return all_agents, active_agents, agent_names, agent_metadata
        
    except Exception as e:
        function_logger.error(f"Error fetching agent data: {str(e)}")
        function_logger.error(f"Error details: {traceback.format_exc()}")
        st.error(f"Error fetching agent data: {str(e)}")
        return "Error", "Error", [], {}

# Fetch token usage for a selected agent
def fetch_agent_metrics(agent_name):
    function_logger = logging.getLogger("agent_ops_dashboard.fetch_agent_metrics")
    function_logger.info(f"Fetching metrics for agent: {agent_name}")
    
    try:
        data = {"query": f"get the latest token usage for the agent {agent_name}"}
        function_logger.debug(f"Sending request to {BASE_URL} for agent metrics")
        response = requests.post(BASE_URL, headers=HEADERS, json=data)
        
        if response.status_code != 200:
            function_logger.error(f"API call failed with status code {response.status_code}")
            function_logger.debug(f"Response content: {response.text[:200]}")
            return {}
            
        metrics = response.json().get("results", [{}])[0]
        function_logger.debug(f"Received metrics: {metrics}")
        return metrics
        
    except Exception as e:
        function_logger.error(f"Error fetching metrics for {agent_name}: {str(e)}")
        function_logger.error(f"Error details: {traceback.format_exc()}")
        st.error(f"Error fetching metrics for {agent_name}")
        return {}

# Fetch model metrics for a selected agent
def fetch_model_metrics(agent_name):
    function_logger = logging.getLogger("agent_ops_dashboard.fetch_model_metrics")
    function_logger.info(f"Fetching model metrics for agent: {agent_name}")
    
    try:
        data = {"query": f"share the model metric of the agent {agent_name}"}
        function_logger.debug(f"Sending request to {BASE_URL} for model metrics")
        response = requests.post(BASE_URL, headers=HEADERS, json=data)
        
        if response.status_code != 200:
            function_logger.error(f"API call failed with status code {response.status_code}")
            function_logger.debug(f"Response content: {response.text[:200]}")
            return {}
            
        metrics = response.json().get("results", [{}])[0]
        function_logger.debug(f"Received model metrics status: {metrics.get('status')}")
        return metrics
        
    except Exception as e:
        function_logger.error(f"Error fetching model metrics for {agent_name}: {str(e)}")
        function_logger.error(f"Error details: {traceback.format_exc()}")
        st.error(f"Error fetching model metrics for {agent_name}")
        return {}

# Bedrock logs retrieval function
def get_model_invocation_logs(
    log_group_name: str,
    agent_id: str,
    region_name: str = 'us-east-1',
    hours_back: int = 24,
    aws_access_key_id=None,
    aws_secret_access_key=None,
    max_logs=100
) -> List[Dict]:
    """
    Read model invocation logs from CloudWatch and filter by agent ID.
    """
    function_logger = logging.getLogger("agent_ops_dashboard.get_model_invocation_logs")
    function_logger.info(f"Retrieving logs for agent '{agent_id}' from CloudWatch")
    function_logger.debug(f"Parameters: log_group={log_group_name}, region={region_name}, " +
                        f"hours_back={hours_back}, max_logs={max_logs}")
    
    # Initialize CloudWatch Logs client
    try:
        function_logger.debug("Initializing CloudWatch client")
        cloudwatch_client = boto3.client(
            'logs', 
            region_name=region_name,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key
        )
    except Exception as e:
        function_logger.error(f"Failed to initialize CloudWatch client: {str(e)}")
        function_logger.debug(f"Error details: {traceback.format_exc()}")
        st.error("Failed to initialize CloudWatch client")
        return []
    
    # Calculate time range (CloudWatch expects timestamps in milliseconds)
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(hours=hours_back)
    start_timestamp = int(start_time.timestamp() * 1000)
    end_timestamp = int(end_time.timestamp() * 1000)
    
    function_logger.info(f"Searching logs from {start_time} to {end_time}")
    
    # Remove full ARN if provided, extract just the username part
    original_agent_id = agent_id
    if 'arn:aws:iam::' in agent_id and '/user/' in agent_id:
        agent_id = agent_id.split('/user/')[-1]
        function_logger.info(f"Extracted username '{agent_id}' from ARN")
        st.markdown('<div class="white-text">Extracted username from ARN: {}</div>'.format(agent_id), unsafe_allow_html=True)
    
    filtered_logs = []
    next_token = None
    request_count = 0
    
    try:
        # Loop to handle pagination of results
        while True:
            request_count += 1
            kwargs = {
                'logGroupName': log_group_name,
                'startTime': start_timestamp,
                'endTime': end_timestamp,
                'limit': 1000  # Maximum allowed by API
            }
            
            if next_token:
                kwargs['nextToken'] = next_token
            
            function_logger.debug(f"Making CloudWatch API request #{request_count}")    
            
            try:
                # Get logs from CloudWatch
                response = cloudwatch_client.filter_log_events(**kwargs)
                
                events_count = len(response.get('events', []))
                function_logger.debug(f"Retrieved {events_count} events in batch #{request_count}")
                
                # Process this batch of logs
                for event in response.get('events', []):
                    try:
                        # Parse the log message as JSON
                        log_data = json.loads(event['message'])
                        
                        # Check if the log is for our agent
                        identity_arn = log_data.get('identity', {}).get('arn', '')
                        
                        # Filter by agent ID - it should appear in the ARN
                        if agent_id in identity_arn:
                            # Add timestamp for reference
                            log_data['cloudwatch_timestamp'] = datetime.fromtimestamp(
                                event['timestamp'] / 1000
                            ).isoformat()
                            
                            filtered_logs.append(log_data)
                            
                            # Break if we have enough logs
                            if len(filtered_logs) >= max_logs:
                                function_logger.info(f"Reached max logs limit ({max_logs})")
                                break
                    except json.JSONDecodeError:
                        continue  # Skip non-JSON messages
                    except Exception as e:
                        function_logger.debug(f"Error processing individual log: {str(e)}")
                        continue  # Skip any errors in processing individual logs
                
                # Break if we have enough logs or there are no more pages
                if len(filtered_logs) >= max_logs or 'nextToken' not in response:
                    break
                    
                next_token = response['nextToken']
                function_logger.debug(f"Retrieved nextToken for pagination")
                
            except Exception as e:
                function_logger.error(f"Error in CloudWatch request #{request_count}: {str(e)}")
                function_logger.debug(f"Error details: {traceback.format_exc()}")
                break
        
        # Sort by timestamp (most recent first)
        filtered_logs.sort(
            key=lambda x: x.get('timestamp', x.get('cloudwatch_timestamp', '')), 
            reverse=True
        )
        
        function_logger.info(f"Retrieved a total of {len(filtered_logs)} logs for agent '{agent_id}'")
        return filtered_logs[:max_logs]  # Limit to max_logs
        
    except Exception as e:
        function_logger.error(f"Error querying CloudWatch logs: {str(e)}")
        function_logger.error(f"Error details: {traceback.format_exc()}")
        st.markdown(f'<div class="white-text">Error querying CloudWatch logs: {str(e)}</div>', unsafe_allow_html=True)
        return []

def parse_logs_for_display(logs):
    """Extract relevant information from logs for display in a table"""
    function_logger = logging.getLogger("agent_ops_dashboard.parse_logs_for_display")
    function_logger.info(f"Parsing {len(logs)} logs for display")
    
    parsed_data = []
    success_count = 0
    error_count = 0
    
    for log in logs:
        try:
            # Extract common fields
            timestamp = log.get('timestamp', log.get('cloudwatch_timestamp', 'Unknown'))
            if isinstance(timestamp, str) and timestamp.endswith('Z'):
                # Convert from ISO format
                timestamp = timestamp.replace('Z', '+00:00')
                try:
                    dt = datetime.fromisoformat(timestamp)
                    timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    function_logger.debug(f"Failed to parse timestamp: {timestamp}")
                
            request_id = log.get('requestId', 'Unknown')
            model_id = log.get('modelId', 'Unknown')
            
            # Extract token counts
            input_tokens = 0
            output_tokens = 0
            
            # Try to get from output.outputBodyJson.usage first
            if 'output' in log and 'outputBodyJson' in log['output']:
                output_body = log['output']['outputBodyJson']
                if isinstance(output_body, str):
                    try:
                        output_body = json.loads(output_body)
                    except:
                        function_logger.debug(f"Failed to parse outputBodyJson for request: {request_id}")
                
                if isinstance(output_body, dict) and 'usage' in output_body:
                    input_tokens = output_body['usage'].get('input_tokens', 0)
                    output_tokens = output_body['usage'].get('output_tokens', 0)
            
            # If we couldn't find token counts above, try input/output fields
            if input_tokens == 0 and 'input' in log:
                input_tokens = log['input'].get('inputTokenCount', 0)
            
            if output_tokens == 0 and 'output' in log:
                output_tokens = log['output'].get('outputTokenCount', 0)
            
            # Extract input message - simplify to show only the last user message for display
            input_message = "No message found"
            if 'input' in log and 'inputBodyJson' in log['input']:
                input_body = log['input']['inputBodyJson']
                
                if isinstance(input_body, str):
                    try:
                        input_body = json.loads(input_body)
                    except:
                        input_message = input_body[:100] + "..." if len(input_body) > 100 else input_body
                        
                if isinstance(input_body, dict) and 'messages' in input_body:
                    messages = input_body.get('messages', [])
                    if messages:
                        # Get the last user message
                        for msg in reversed(messages):
                            if isinstance(msg, dict) and msg.get('role') == 'user':
                                content = msg.get('content', '')
                                if isinstance(content, list):  # Handle array content
                                    text_content = []
                                    for item in content:
                                        if isinstance(item, dict) and 'text' in item:
                                            text_content.append(item['text'])
                                    if text_content:
                                        content = ' '.join(text_content)
                                if content:
                                    input_message = content[:100] + "..." if len(content) > 100 else content
                                    break
            
            # Extract output message
            output_message = "No response found"
            if 'output' in log and 'outputBodyJson' in log['output']:
                output_body = log['output']['outputBodyJson']
                
                if isinstance(output_body, str):
                    try:
                        output_body = json.loads(output_body)
                    except:
                        output_message = output_body[:100] + "..." if len(output_body) > 100 else output_body
                
                if isinstance(output_body, dict):
                    if 'content' in output_body:
                        content = output_body['content']
                        if isinstance(content, list):
                            text_parts = []
                            for part in content:
                                if isinstance(part, dict):
                                    if part.get('type') == 'text':
                                        text_parts.append(part.get('text', ''))
                                    elif part.get('type') == 'tool_use':
                                        text_parts.append(f"Tool: {part.get('name', '')}")
                            if text_parts:
                                output_message = ' '.join(text_parts)[:100] + "..." if len(' '.join(text_parts)) > 100 else ' '.join(text_parts)
                        else:
                            output_message = str(content)[:100] + "..." if len(str(content)) > 100 else str(content)
            
            # Add to results - ensure all fields are strings to avoid PyArrow conversion issues
            parsed_data.append({
                'Timestamp': str(timestamp),
                'Request ID': str(request_id),
                'Model ID': str(model_id),
                'Input Tokens': int(input_tokens),
                'Output Tokens': int(output_tokens),
                'Total Tokens': int(input_tokens + output_tokens),
                'Input Message': str(input_message),
                'Output Message': str(output_message)
            })
            
            success_count += 1
            
        except Exception as e:
            function_logger.error(f"Error parsing log entry: {str(e)}")
            function_logger.debug(f"Error details: {traceback.format_exc()}")
            function_logger.debug(f"Problematic log: {log}")
            error_count += 1
    
    function_logger.info(f"Successfully parsed {success_count} logs, encountered {error_count} errors")
    return parsed_data

def get_log_content():
    """Helper function to read the log file contents for display in the app"""
    try:
        with open(log_filename, 'r') as file:
            return file.read()
    except Exception as e:
        logger.error(f"Error reading log file: {str(e)}")
        return f"Error reading log file: {str(e)}"

# Main app
try:
    # Check if header.png exists, load it if it does
    import os
    if os.path.exists("header.png"):
        logger.debug("Found header.png, displaying it")
        st.image("header.png", use_container_width=True)
except Exception as e:
    logger.debug(f"Header image not found or error displaying it: {str(e)}")
    pass  # Just continue if header image doesn't exist

# Dashboard tabs
tab1, tab2, tab3 = st.tabs(["Agent Dashboard", "Bedrock Invocation Logs", "Application Logs"])

with tab1:
    # Dashboard Header
    logger.info("Rendering Agent Dashboard tab")
    st.markdown('<div class="white-text"><h2> <b>AI Agent Factory</b></h2></div>', unsafe_allow_html=True)
    st.markdown('<div class="white-text"><p><b>Welcome!</b> This dashboard provides real-time insights into your registered and active agents.</p></div>', unsafe_allow_html=True)
    
    # Fetch and store agent data
    if "agent_data" not in st.session_state:
        logger.info("Fetching agent data for the first time")
        st.session_state.agent_data = fetch_counts_and_metadata()
    
    all_agents, active_agents, agent_names, agent_metadata = st.session_state.agent_data
    # Agent Counts
    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"""
            <div class="metric-box">
                <div class="metric-label"><b>Registered Agents</b></div>
                <div class="metric-value">{all_agents}</div>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
            <div class="metric-box">
                <div class="metric-label"><b>Active Agents</b></div>
                <div class="metric-value">{active_agents}</div>
            </div>
        """, unsafe_allow_html=True)
    
    # Agent selection
    st.markdown("<br><br>", unsafe_allow_html=True)
    
    st.markdown('<div class="white-text"><h3> <b>Agent Metrics</b></h3></div>', unsafe_allow_html=True)
    selected_agent = st.selectbox("", agent_names, key="agent_select")
    
    # Store selected agent in session state for use in other tabs
    if selected_agent and selected_agent != st.session_state.get('selected_agent'):
        logger.info(f"User selected agent: {selected_agent}")
        st.session_state['selected_agent'] = selected_agent
        # Get ARN ID for the selected agent - save for Bedrock logs tab
        if agent_metadata and selected_agent in agent_metadata:
            arn_id = agent_metadata[selected_agent].get('arn_id')
            st.session_state['agent_arn_id'] = arn_id
            logger.info(f"Stored ARN ID for {selected_agent}: {arn_id}")
    
    # Display selected agent description and metrics
    if selected_agent:
        agent_info = agent_metadata.get(selected_agent, {})
        
        # Get the ARN ID for this agent
        agent_arn_id = agent_info.get('arn_id')
        logger.debug(f"Selected agent ARN ID: {agent_arn_id}")
    
        metrics = fetch_agent_metrics(selected_agent)
        input_tokens = metrics.get("total_input_tokens", 0)
        output_tokens = metrics.get("total_output_tokens", 0)
        total_requests = metrics.get("total_events", 0)
        total_cost = (input_tokens / 1_000_000) * 3 + (output_tokens / 1_000_000) * 15
        
        logger.info(f"Agent metrics - Input tokens: {input_tokens}, Output tokens: {output_tokens}, " +
                  f"Total requests: {total_requests}, Total cost: ${total_cost:.2f}")
    
        st.markdown(f"""
          <div class="metric-box">
              <div class="metric-value"><b>{selected_agent}</b></div>
              <div class="metric-value" style="font-size:18px;">{agent_info.get("desc", "No description available")}</div>
          </div>
      """, unsafe_allow_html=True)
    
        col1, col2 = st.columns(2)
    
        with col1:
            st.markdown(f"""
                <div class="metric-box">
                    <div class="metric-label"><b>Total Requests</b></div>
                    <div class="metric-value">{total_requests}</div>
                </div>
                <div class="metric-box">
                    <div class="metric-label"><b>Input Tokens</b></div>
                    <div class="metric-value">{input_tokens}</div>
                </div>
            """, unsafe_allow_html=True)
    
        with col2:
            st.markdown(f"""
                <div class="metric-box">
                    <div class="metric-label"><b>Total Cost</b></div>
                    <div class="metric-value">${total_cost:.2f}</div>
                </div>
                <div class="metric-box">
                    <div class="metric-label"><b>Output Tokens</b></div>
                    <div class="metric-value">{output_tokens}</div>
                </div>
            """, unsafe_allow_html=True)
    
        st.markdown("<br><br>", unsafe_allow_html=True)
    
        st.markdown(f'<div class="white-text"><h4> <b>Agent Performance - {selected_agent}</b></h4></div>', unsafe_allow_html=True)
        model_metrics = fetch_model_metrics(selected_agent)
    
        if model_metrics.get("status") == "success":
            metric_map = {
                "InvocationLatency": "Invocation Latency (ms)",
                "ModelInvocationClientErrors": "Client Errors",
                "ModelInvocationServerErrors": "Server Errors"
            }
    
            col1, col2, col3 = st.columns(3)
            for metric in model_metrics.get("metrics", []):
                if metric["metric"] in metric_map:
                    label = metric_map[metric["metric"]]
                    latest_value = metric["values"][0] if metric["values"] else "N/A"
                    logger.debug(f"Model metric - {label}: {latest_value}")
    
                    with col1 if metric["metric"] == "InvocationLatency" else \
                         col2 if metric["metric"] == "ModelInvocationClientErrors" else col3:
                        st.markdown(f"""
                            <div class="metric-box">
                                <div class="metric-label"><b>{label}</b></div>
                                <div class="metric-value">{latest_value}</div>
                            </div>
                        """, unsafe_allow_html=True)
        else:
            logger.warning(f"Failed to fetch model metrics for {selected_agent}")
            st.markdown('<div class="white-text">Failed to fetch model metrics</div>', unsafe_allow_html=True)
        
        # Get MongoDB cost data if agent_arn_id is available
        if agent_arn_id:
            logger.info(f"Fetching MongoDB cost data for agent: {agent_arn_id}")
            with st.spinner('Calculating costs from MongoDB...'):
                # Get cost data directly using the improved function
                df_cost, lifetime_cost, total_tokens, total_invocations = calculate_daily_costs_from_mongo(agent_arn_id)
                
                # Display lifetime metrics in a row
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown('<div class="white-text"><h4><b>Lifetime Usage Statistics</b></h4></div>', unsafe_allow_html=True)
                
                cols = st.columns(4)
                cols[0].metric("Total Lifetime Cost", f"${lifetime_cost:.2f}")
                cols[1].metric("Total Tokens Processed", f"{total_tokens:,}")
                cols[2].metric("Total API Calls", f"{total_invocations:,}")
                cols[3].metric("Avg Tokens per Call", f"{int(total_tokens/total_invocations) if total_invocations > 0 else 0:,}")
                
                if df_cost.empty or df_cost["Cost (USD)"].sum() == 0:
                    # Fallback to dummy data if no logs or costs found
                    logger.warning("No cost data found in MongoDB, using sample data")
                    st.markdown('<div class="white-text">No cost data found for the last 7 days in MongoDB. Showing sample data.</div>', unsafe_allow_html=True)
                    
                    # Create sample daily costs data and calculate cumulative costs
                    cost_dates = pd.date_range(end=pd.Timestamp.today(), periods=7)
                    # Daily costs
                    daily_cost_values = [3.06, 5.84, 3.4, 0.2, 10.5, 2.25, 5.71]
                    # Calculate cumulative costs
                    cumulative_cost_values = []
                    running_total = 0
                    for val in daily_cost_values:
                        running_total += val
                        cumulative_cost_values.append(running_total)
                    
                    df_cost = pd.DataFrame({
                        "Date": cost_dates, 
                        "Daily Cost (USD)": daily_cost_values,
                        "Cost (USD)": cumulative_cost_values
                    })
                    df_cost["Date"] = df_cost["Date"].dt.strftime('%b %d')  # Shorten date format
        else:
            # Fallback to dummy data if no ARN ID is available
            logger.warning(f"No ARN ID available for {selected_agent}, using sample cost data")
            cost_dates = pd.date_range(end=pd.Timestamp.today(), periods=7)
            # Daily costs
            daily_cost_values = [3.06, 5.84, 3.4, 0.2, 10.5, 2.25, 5.71]
            # Calculate cumulative costs
            cumulative_cost_values = []
            running_total = 0
            for val in daily_cost_values:
                running_total += val
                cumulative_cost_values.append(running_total)
            
            df_cost = pd.DataFrame({
                "Date": cost_dates, 
                "Daily Cost (USD)": daily_cost_values,
                "Cost (USD)": cumulative_cost_values
            })
            df_cost["Date"] = df_cost["Date"].dt.strftime('%b %d')  # Shorten date format
            
            # Display dummy lifetime metrics
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown('<div class="white-text"><h4><b>Lifetime Usage Statistics</b></h4></div>', unsafe_allow_html=True)
            
            cols = st.columns(4)
            cols[0].metric("Total Lifetime Cost", "\$31.00")
            cols[1].metric("Total Tokens Processed", "1,523,450")
            cols[2].metric("Total API Calls", "485")
            cols[3].metric("Avg Tokens per Call", "3,141")
    
        # Dummy data for latency over the last 3 days
        latency_dates = pd.date_range(end=pd.Timestamp.today(), periods=3)
        latency_values = [1800 , 548, 846]
        df_latency = pd.DataFrame({"Date": latency_dates, "Latency (ms)": latency_values})
        df_latency["Date"] = df_latency["Date"].dt.strftime('%b %d')  # Shorten date format
    
        # Set seaborn theme
        sns.set_theme(style="whitegrid")
        logger.info("Generating charts")
    
        # Create side-by-side plots
        col1, col2 = st.columns(2)
    
        with col1:
            st.markdown('<div class="white-text"><h4><b>Budget vs Spend (Cumulative)</b></h4></div>', unsafe_allow_html=True)
            fig1, ax1 = plt.subplots(figsize=(6, 4))
            sns.lineplot(data=df_cost, x="Date", y="Cost (USD)", marker="o", ax=ax1, color="blue")
            
            # Calculate threshold as 120% of the final cumulative cost or minimum \$35
            threshold = df_cost["Cost (USD)"].iloc[-1] * 1.2 if not df_cost.empty and df_cost["Cost (USD)"].iloc[-1] > 0 else 35
            ax1.axhline(y=threshold, color='red', linestyle='--', label=f'Threshold (\${threshold:.2f})')
            
            ax1.set_title("Cumulative Cost Over Time", fontsize=14)
            ax1.set_xlabel("Date")
            ax1.set_ylabel("Cumulative Cost (USD)")
            ax1.legend()
            plt.xticks(rotation=45)
            st.pyplot(fig1)
            logger.debug(f"Generated cost chart with threshold: \${threshold:.2f}")
    
        with col2:
            st.markdown('<div class="white-text"><h4><b>Agent Response</b></h4></div>', unsafe_allow_html=True)
            fig2, ax2 = plt.subplots(figsize=(6, 4))
            sns.lineplot(data=df_latency, x="Date", y="Latency (ms)", marker="o", ax=ax2, color="orange")
            ax2.set_title("Latency Over Time", fontsize=14)
            ax2.set_xlabel("Date")
            ax2.set_ylabel("Latency (ms)")
            plt.xticks(rotation=45)
            st.pyplot(fig2)
            logger.debug("Generated latency chart")
    
        # # Critical Alerts
        # critical_alerts = [
        #     ["07-02 15:45","Agent Monitor", "Failure rate at 35% in the last 10 mins. Check upstream service errors or degradation."],
        #     ["07-02 10:06","TextAgent", "Accuracy dropped to 72% (Threshold: 85%). Possible drift or misalignment."],
        #     ["07-01 23:36","MathAgent", "Exceeded max response time. Latency:12.4s (Threshold: 8s). Investigate Immediately."],
        #     ["07-01 18:39","TextAgent", "Showing low confidence scores on 40% of queries. Consider review or retraining."],
        #     ["07-01 15:06","Agent Monitor", "CPU usage at 95% (avg: 65%) for last 5 mins. Scaling may be needed."]
        # ]
        # df_critical = pd.DataFrame(critical_alerts, columns=["Timestamp","Agent Name", "Alert Message"])
    
        # # Warning Alerts
        # warning_alerts = [
        #     ["07-02 12:15","Agent Monitor", "Response latency trending upward. Current: 6.2s | Baseline: 3.5s"],
        #     ["07-02 11:46","Agent Monitor", "Retry count increased by 60% in the last hour. Backend stability suspected."],
        #     ["07-02 08:30","TextAgent", "CSAT dropped to 3.2/5.0. Check recent interaction samples."],
        #     ["07-02 00:45","MathAgent", "Memory usage increased by 40% over 10 mins. Potential memory leak."]
        # ]
        # df_warning = pd.DataFrame(warning_alerts, columns=["Timestamp","Agent Name", "Alert Message"])
    
        # Display tables
        st.markdown("<br>", unsafe_allow_html=True)
    
        st.markdown('<div class="alert-header"><b> Critical Alerts</b><br></div>', unsafe_allow_html=True)
        #st.dataframe(df_critical,hide_index=True)
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('<div class="white-text">No Critical Alerts to display</div>', unsafe_allow_html=True)

        st.markdown('<div class="alert-header"><b> Warning Level Alerts</b><br></div>', unsafe_allow_html=True)
        #st.dataframe(df_warning, hide_index=True)
        st.markdown('<div class="white-text">No Warning Alerts to display</div>', unsafe_allow_html=True)
with tab2:
    logger.info("Rendering Bedrock Invocation Logs tab")
    st.markdown('<div class="white-text"><h2> <b>Bedrock Model Invocation Logs</b></h2></div>', unsafe_allow_html=True)
    
    # Container for Bedrock logs configuration
    with st.container():
        st.markdown('<div class="white-text"><h4> <b>Log Configuration</b></h4></div>', unsafe_allow_html=True)
        
        # Use selected agent from first tab if available
        default_agent_id = ""
        if "selected_agent" in st.session_state:
            selected_agent_name = st.session_state["selected_agent"]
            if "agent_arn_id" in st.session_state:
                default_agent_id = st.session_state["agent_arn_id"]
                logger.debug(f"Using agent ARN ID from tab1: {default_agent_id}")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # Get config from file
            use_config_file = st.checkbox('Use config_server.json', value=True, key="use_config_checkbox")
            
            if use_config_file:
                logger.debug("User selected to use config file")
                config = read_aws_config()
                if config:
                    aws_access_key_id = config.get('aws_access_key_id')
                    aws_secret_access_key = config.get('aws_secret_access_key')
                    region_name = config.get('region_name', 'us-east-1')
                    
                    # Show masked key ID
                    if aws_access_key_id:
                        masked_key = aws_access_key_id[:4] + '*****' + aws_access_key_id[-4:] if len(aws_access_key_id) > 8 else "****"
                        logger.debug(f"Using AWS credentials from config file, region: {region_name}")
                        st.markdown(f'<div class="white-text">Using credentials (Key ID: {masked_key})</div>', unsafe_allow_html=True)
                else:
                    logger.warning("Failed to load AWS config file")
                    st.markdown('<div class="white-text">Failed to load config. Please enter credentials manually.</div>', unsafe_allow_html=True)
                    use_config_file = False
            
            if not use_config_file:
                logger.debug("User entering AWS credentials manually")
                aws_access_key_id = st.text_input('AWS Access Key ID', key="aws_key_input")
                aws_secret_access_key = st.text_input('AWS Secret Access Key', type='password', key="aws_secret_input")
                region_name = st.text_input('AWS Region', value='us-east-1', key="aws_region_input")
        
        with col2:
            # Time range and log count
            log_group_name = st.text_input('CloudWatch Log Group', value='/aws/bedrock/model-invocations', key="log_group_input")
            hours_back = st.slider('Hours back', min_value=1, max_value=72, value=24, key="hours_slider", on_change=None)
            max_logs = st.slider('Max logs', min_value=5, max_value=100, value=20, key="max_logs_slider", on_change=None)
            logger.debug(f"Log settings: group={log_group_name}, hours_back={hours_back}, max_logs={max_logs}")
        
        with col3:
            # Agent selection - if no selection from tab1, show manual input
            if not default_agent_id:
                agent_id = st.text_input('Agent ID (e.g., agentops-iam-user)', key="agent_id_input")
                st.markdown('<div class="white-text">Enter the agent\'s ARN ID or just the username part</div>', unsafe_allow_html=True)
                logger.debug(f"User entered agent ID: {agent_id}")
            else:
                st.markdown(f'<div class="white-text">Using agent: {selected_agent_name}</div>', unsafe_allow_html=True)
                st.markdown(f'<div class="white-text">ARN ID: {default_agent_id}</div>', unsafe_allow_html=True)
                agent_id = default_agent_id
                logger.debug(f"Using agent ID from tab1: {agent_id}")
            
            # Add fetch button
            fetch_logs = st.button('Fetch Logs', key="fetch_logs_btn")
            if fetch_logs:
                logger.info(f"User clicked 'Fetch Logs' button. Agent ID: {agent_id}")
    
    # Process fetch logs request
    if fetch_logs:
        if not agent_id:
            logger.warning("User attempted to fetch logs without specifying an Agent ID")
            st.markdown('<div class="white-text">Please enter an Agent ID or select an agent from the Dashboard tab</div>', unsafe_allow_html=True)
        elif not aws_access_key_id or not aws_secret_access_key:
            logger.warning("User attempted to fetch logs without providing AWS credentials")
            st.markdown('<div class="white-text">AWS credentials are required</div>', unsafe_allow_html=True)
        else:
            # Show loading message
            with st.spinner('Fetching logs from CloudWatch...'):
                logger.info(f"Fetching CloudWatch logs for agent '{agent_id}' (hours back: {hours_back}, max logs: {max_logs})")
                # Fetch logs
                logs = get_model_invocation_logs(
                    log_group_name=log_group_name,
                    agent_id=agent_id,
                    region_name=region_name,
                    hours_back=hours_back,
                    aws_access_key_id=aws_access_key_id,
                    aws_secret_access_key=aws_secret_access_key,
                    max_logs=max_logs
                )
                
                if logs:
                    logger.info(f"Successfully retrieved {len(logs)} logs from CloudWatch")
                    # Parse logs for display
                    parsed_logs = parse_logs_for_display(logs)
                    
                    # Store in session state for display
                    st.session_state['bedrock_logs'] = logs
                    st.session_state['parsed_bedrock_logs'] = parsed_logs
                    
                    st.markdown(f'<div class="white-text">Successfully retrieved {len(logs)} logs</div>', unsafe_allow_html=True)
                else:
                    logger.warning(f"No logs found for agent '{agent_id}'")
                    # Store empty results
                    st.session_state['bedrock_logs'] = []
                    st.session_state['parsed_bedrock_logs'] = []
                    st.markdown(f'<div class="white-text">No logs found for agent \'{agent_id}\'</div>', unsafe_allow_html=True)
    
    # Display logs in a table
    if 'parsed_bedrock_logs' in st.session_state:
        logger.debug("Displaying parsed Bedrock logs from session state")
        st.markdown('<div class="logs-container">', unsafe_allow_html=True)
        
        if st.session_state['parsed_bedrock_logs']:
            # Create DataFrame for table display
            df = pd.DataFrame(st.session_state['parsed_bedrock_logs'])
            
            # Display token usage metrics
            col1, col2, col3, col4 = st.columns(4)
            
            total_input_tokens = df['Input Tokens'].sum()
            total_output_tokens = df['Output Tokens'].sum()
            total_tokens = df['Total Tokens'].sum()
            avg_tokens_per_request = int(total_tokens / len(df)) if len(df) > 0 else 0
            
            logger.info(f"Log summary: {len(df)} requests, {total_input_tokens} input tokens, " +
                      f"{total_output_tokens} output tokens, avg: {avg_tokens_per_request} tokens/request")
            
            # Use metric widget with white text added in CSS
            col1.metric("Total Requests", len(df))
            col2.metric("Total Input Tokens", f"{total_input_tokens:,}")
            col3.metric("Total Output Tokens", f"{total_output_tokens:,}")
            col4.metric("Avg. Tokens/Request", f"{avg_tokens_per_request:,}")
            
            # Display the table with selected columns for overview
            st.markdown('<div class="white-text"><h4><b>Log Events Summary</b></h4></div>', unsafe_allow_html=True)
            st.dataframe(df[['Timestamp', 'Request ID', 'Model ID', 'Input Tokens', 'Output Tokens', 'Total Tokens']], use_container_width=True)
            
            # Add expandable sections for viewing details - Fix the PyArrow error by converting to strings
            with st.expander("View Request Messages"):
                logger.debug("User expanded 'View Request Messages'")
                # Convert to strings and create a new dataframe to avoid PyArrow conversion issues
                request_messages_df = pd.DataFrame({
                    'Request ID': df['Request ID'].astype(str),
                    'Input Message': df['Input Message'].astype(str)
                })
                st.dataframe(request_messages_df, use_container_width=True)
            
            with st.expander("View Response Messages"):
                logger.debug("User expanded 'View Response Messages'")
                # Convert to strings and create a new dataframe to avoid PyArrow conversion issues
                response_messages_df = pd.DataFrame({
                    'Request ID': df['Request ID'].astype(str),
                    'Output Message': df['Output Message'].astype(str)
                })
                st.dataframe(response_messages_df, use_container_width=True)
            
            # Option to download full logs as JSON - prevent page reload
            dl_json = json.dumps(st.session_state['bedrock_logs'], indent=2, default=str)
            dl_filename = f"bedrock_logs_{agent_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            st.download_button(
                label="Download Full Logs (JSON)",
                data=dl_json,
                file_name=dl_filename,
                mime="application/json",
                key="download_logs_btn"
            )
            logger.debug(f"Created download button for logs JSON file: {dl_filename}")
                
        else:
            logger.warning("No parsed logs to display")
            st.markdown('<div class="white-text">No logs found for the specified agent.</div>', unsafe_allow_html=True)
            
            st.markdown('<div class="white-text">Possible reasons:</div>', unsafe_allow_html=True)
            st.markdown("""
            <div class="white-text">
            1. The agent ID might be incorrect or the format is wrong<br>
            2. No Bedrock model invocations for this agent in the selected time range<br>
            3. CloudWatch logs might not be enabled for Bedrock
            </div>
            """, unsafe_allow_html=True)
            
        st.markdown('</div>', unsafe_allow_html=True)
    
    else:
        logger.debug("No logs in session state yet")
        st.markdown('<div class="white-text">Please configure the agent ID and click "Fetch Logs" to view model invocation logs</div>', unsafe_allow_html=True)

# Application logs tab
with tab3:
    logger.info("Rendering Application Logs tab")
    st.markdown('<div class="white-text"><h2><b>Application Logs</b></h2></div>', unsafe_allow_html=True)
    
    # Display log levels and filtering options
    st.markdown('<div class="white-text"><h4>Log Settings</h4></div>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        log_level = st.selectbox(
            "Log Level",
            ["INFO", "DEBUG", "WARNING", "ERROR", "ALL"],
            index=0
        )
        logger.debug(f"User selected log level filter: {log_level}")
    
    with col2:
        search_term = st.text_input("Search Logs", placeholder="Enter keywords to filter logs")
        if search_term:
            logger.debug(f"User filtered logs with search term: '{search_term}'")
    
    with col3:
        refresh_logs = st.button("Refresh Logs")
        if refresh_logs:
            logger.info("User clicked 'Refresh Logs' button")
    
    # Read and filter logs
    log_content = get_log_content()
    
    # Filter by level if not ALL
    filtered_lines = []
    for line in log_content.split('\n'):
        include_line = True
        
        # Filter by log level
        if log_level != "ALL":
            if f"[{log_level}]" not in line:
                include_line = False
                
        # Filter by search term if provided
        if search_term and search_term.strip():
            if search_term.lower() not in line.lower():
                include_line = False
        
        if include_line:
            filtered_lines.append(line)
    
    filtered_content = '\n'.join(filtered_lines)
    
    # Style the log output for better readability
    styled_logs = filtered_content.replace("[ERROR]", '<span class="log-error">[ERROR]</span>')
    styled_logs = styled_logs.replace("[WARNING]", '<span class="log-warning">[WARNING]</span>')
    styled_logs = styled_logs.replace("[INFO]", '<span class="log-info">[INFO]</span>')
    styled_logs = styled_logs.replace("[DEBUG]", '<span class="log-debug">[DEBUG]</span>')
    
    # Display the styled logs
    st.markdown(f'<div class="log-viewer">{styled_logs}</div>', unsafe_allow_html=True)
    
    # Download button for logs
    st.download_button(
        label="Download Full Logs",
        data=log_content,
        file_name=f"agent_ops_dashboard_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log",
        mime="text/plain"
    )
    logger.debug("Created download button for application logs")

# Log application exit - this will only run when the script is reloaded
logger.info(f"Application session {session_id} ended or reloaded")