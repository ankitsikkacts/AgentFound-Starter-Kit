# Startup command uvicorn fastapi_endpoint:app --port 9000 --reload
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import json
import uuid
import logging
from typing import Dict
from BaseAgent import BaseCoordinator, BaseAgent
from RegistrationAgent import RegistrationAgent
from LoggingMetricAgent import LoggingMetricAgent
from pydantic import BaseModel


"""Example usage of the LangGraph multiagent system"""
# Replace with your actual AWS credentials

AWS_ACCESS_KEY_ID = "AKIAVAYAJDYXQ3B4FS4L"
AWS_SECRET_ACCESS_KEY = "Mdmr7OqMm9HjmoaMTEAb6U2Ylsf5p05YY8H0x/kG"

# AWS_ACCESS_KEY_ID = "AKIAVAYAJDYXQKZOD6PC"
# AWS_SECRET_ACCESS_KEY = "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"
AWS_REGION = "us-east-1"

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CoordinatorAgent(BaseCoordinator):
    """Coordinator agent that manages different specialized agents"""
    
    def _initialize_agents(self) -> Dict[str, BaseAgent]:
        """Initialize all available agents"""
        return {
            "registration": RegistrationAgent(self.aws_access_key_id, self.aws_secret_access_key, self.region_name),
            "logging_token_metric": LoggingMetricAgent(self.aws_access_key_id, self.aws_secret_access_key, self.region_name)
        }

class MultiAgentSystem:
    """Main multiagent system using LangGraph"""
    
    def __init__(self, aws_access_key_id: str, aws_secret_access_key: str, region_name: str = 'us-east-1'):
        self.coordinator = CoordinatorAgent(aws_access_key_id, aws_secret_access_key, region_name)
        logger.info("MultiAgent system initialized with LangGraph")
    
    def process_request(self, user_input: str, thread_id: str = "default") -> str:
        """Process a user request"""
        return self.coordinator.process_request(user_input, thread_id)
    
    def list_agents(self) -> Dict[str, str]:
        """List all available agents"""
        return self.coordinator.list_agents()
    
    def get_conversation_history(self, agent_type: str = "math", thread_id: str = "default") -> list:
        """Get conversation history"""
        return self.coordinator.get_agent_conversation_history(agent_type, thread_id)
    def get_active_agents_count(self) -> int:  #<<<<-------------MODIFIED LINE
        return 0 # Default if no agents are active, to be mocked in test #<<<<-------------MODIFIED LINE

system = MultiAgentSystem(
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            region_name=AWS_REGION
        )
        

# Define the request model
class QueryRequest(BaseModel):
    query: str


app = FastAPI()

# List of allowed origins
origins = [
"http://localhost",
"http://localhost:8080",
"http://localhost:8501",
"http://localhost:8502",
"http://localhost:8503",
"http://localhost:8504",
"https://localhost:9000",
"https://d3vk1opd9ea861.cloudfront.net"
]

# Adding CORS middleware to the FastAPI application
app.add_middleware(
CORSMiddleware,
allow_origins=origins, # List of allowed origins
allow_credentials=True, # Allow credentials (cookies, authorization headers, etc.)
allow_methods=["*"], # Allow all HTTP methods
allow_headers=["*"], # Allow all HTTP headers
)


@app.get("/get_all_agents")
#@app.get("/call_agentOps_agent")
def get_all_agents():
     # List available agents
     print("Available agents:")
     # Get the dictionary of agents
     agents_dict = system.list_agents() # This line defines agents_dict  <--- MODIFIED LINE
     for agent_name, description in system.list_agents().items():
         print(f"- {agent_name}: {description}")
     #return {"agents": system.list_agents().items()}
     return {"agents": list(agents_dict.items())} # <--- MODIFIED LINE

@app.post("/call_agentOps_agent")
def trigger_agent_call(request: QueryRequest):
        uuid_gen = uuid.uuid4()
        print(uuid_gen)
        print(request.query)
        response = system.process_request(request.query, uuid_gen)
        # curl -X POST http://127.0.0.1:8000/call_agentOps_agent   \
        #-H "Content-Type: application/json" -d '{"query": "provide the count of registered agents"}'
        print(response)
        response = json.loads(response)
        return response

@app.get("/get_active_agents_count") #<<<<-------------NEW TEST CASE
def get_active_agents_count_endpoint():
    """
    Endpoint to retrieve the count of currently active agents.
    """
    active_count = system.get_active_agents_count()
    return {"active_agents_count": active_count}

