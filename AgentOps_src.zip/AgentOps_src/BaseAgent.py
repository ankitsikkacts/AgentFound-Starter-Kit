"""
Base classes for the multi-agent system.
Contains common functionality shared across all agents and coordinators.
"""

import logging
from typing import Dict, Any, List, Annotated, TypedDict
from abc import ABC, abstractmethod
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, AIMessage
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import MemorySaver
import operator
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Define the state for our graph
class AgentState(TypedDict):
    messages: Annotated[List[Any], operator.add]
    current_agent: str
    task_type: str

class BaseAgent(ABC):
    """Abstract base class for all agents with common functionality"""
    
    def __init__(self, aws_access_key_id: str, aws_secret_access_key: str, region_name: str = 'us-east-1'):
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.region_name = region_name
        self.llm = self._setup_llm()
        self.tools = self._get_tools()
        self.llm_with_tools = self.llm.bind_tools(self.tools) if self.tools else self.llm
        self.graph = self._create_graph()
        self.memory = MemorySaver()
        self.app = self.graph.compile(checkpointer=self.memory)
    
    def _setup_llm(self) -> ChatBedrock:
        """Setup the AWS Bedrock LLM - common for all agents"""
        return ChatBedrock(
            model_id="anthropic.claude-3-sonnet-20240229-v1:0",
            aws_access_key_id=self.aws_access_key_id,
            aws_secret_access_key=self.aws_secret_access_key,
            region_name=self.region_name,
            model_kwargs={
                "temperature": 0.0,
                "max_tokens": 1000
            }
        )
    
    def _create_graph(self) -> StateGraph:
        """Create the LangGraph workflow - common structure for all agents"""
        workflow = StateGraph(MessagesState)
        workflow.add_node("agent", self._agent_node)
        
        if self.tools:
            workflow.add_node("tools", ToolNode(self.tools))
            workflow.add_edge(START, "agent")
            workflow.add_conditional_edges(
                "agent",
                self._should_continue,
                {
                    "continue": "tools",
                    "end": END,
                },
            )
            workflow.add_edge("tools", "agent")
        else:
            workflow.add_edge(START, "agent")
            workflow.add_edge("agent", END)
        
        return workflow
    
    def _agent_node(self, state: MessagesState) -> Dict[str, Any]:
        """Agent node that processes messages - uses agent-specific system message"""
        messages = state["messages"]
        system_message = self._get_system_message()
        full_messages = [HumanMessage(content=system_message)] + messages
        response = self.llm_with_tools.invoke(full_messages)
        
        # Check if this agent requires JSON-only responses
        if self._requires_json_only():
            return self._handle_json_only_response(state, response)
        
        return {"messages": [response]}
    
    def _requires_json_only(self) -> bool:
        """Override in subclasses that need JSON-only responses"""
        return False
    
    def _handle_json_only_response(self, state: MessagesState, response) -> Dict[str, Any]:
        """Handle JSON-only response requirements"""
        messages = state["messages"]
        
        # If the response has tool calls, let them execute
        if hasattr(response, 'tool_calls') and response.tool_calls:
            return {"messages": [response]}
        
        # Check if we have tool results in recent messages
        tool_results = []
        for msg in reversed(messages[-5:]):  # Check last 5 messages
            if hasattr(msg, 'type') and msg.type == 'tool':
                tool_results.append(msg.content)
        
        # If we have tool results, return them as JSON instead of LLM summary
        if tool_results:
            if len(tool_results) == 1:
                # Single tool result - return it directly if it's JSON
                try:
                    json.loads(tool_results[0])
                    return {"messages": [AIMessage(content=tool_results[0])]}
                except:
                    pass
            else:
                # Multiple tool results - combine them
                combined_result = {
                    "status": "success",
                    "results": []
                }
                for result in tool_results:
                    try:
                        parsed = json.loads(result)
                        combined_result["results"].append(parsed)
                    except:
                        combined_result["results"].append({"raw_output": result})
                
                return {"messages": [AIMessage(content=json.dumps(combined_result, indent=2))]}
        
        # If response content exists and is JSON, return it
        if hasattr(response, 'content'):
            content = response.content.strip()
            try:
                json.loads(content)
                return {"messages": [response]}
            except:
                # Force JSON error response
                json_error = json.dumps({
                    "status": "error",
                    "message": "Response must be valid JSON format"
                })
                return {"messages": [AIMessage(content=json_error)]}
        
        # Default fallback
        return {"messages": [response]}
    
    def _should_continue(self, state: MessagesState) -> str:
        """Determine whether to continue with tool calls or end - common logic"""
        messages = state["messages"]
        last_message = messages[-1]
        if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
            return "continue"
        return "end"
    
    def process_request(self, user_input: str, thread_id: str = "default") -> str:
        """Process a user request and return the response - common implementation"""
        try:
            input_message = HumanMessage(content=user_input)
            config = {"configurable": {"thread_id": thread_id}}
            result = self.app.invoke({"messages": [input_message]}, config=config)
            final_message = result["messages"][-1]
            
            # For JSON-only agents, validate the response
            if self._requires_json_only():
                content = final_message.content if hasattr(final_message, 'content') else str(final_message)
                try:
                    json.loads(content)
                    return content
                except:
                    return json.dumps({
                        "status": "error",
                        "message": "Invalid JSON response format"
                    })
            
            return final_message.content if hasattr(final_message, 'content') else str(final_message)
            
        except Exception as e:
            error_msg = f"Error processing request: {str(e)}"
            logger.error(error_msg)
            
            # Return JSON error for JSON-only agents
            if self._requires_json_only():
                return json.dumps({
                    "status": "error", 
                    "message": error_msg
                })
            
            return error_msg
    
    def get_conversation_history(self, thread_id: str = "default") -> List[Dict]:
        """Get conversation history for a specific thread - common implementation"""
        try:
            config = {"configurable": {"thread_id": thread_id}}
            current_state = self.app.get_state(config)
            if current_state and "messages" in current_state.values:
                messages = current_state.values["messages"]
                history = []
                for msg in messages:
                    if hasattr(msg, 'type'):
                        history.append({
                            "type": msg.type,
                            "content": msg.content if hasattr(msg, 'content') else str(msg)
                        })
                return history
            return []
        except Exception as e:
            logger.error(f"Error getting conversation history: {e}")
            return []
    
    # Abstract methods that each agent must implement
    @abstractmethod
    def _get_tools(self) -> List:
        """Return the tools specific to this agent"""
        pass
    
    @abstractmethod
    def _get_system_message(self) -> str:
        """Return the system message specific to this agent"""
        pass
    
    @abstractmethod
    def get_agent_description(self) -> str:
        """Return a description of what this agent does"""
        pass

class BaseCoordinator:
    """Base coordinator class with common routing functionality"""
    
    def __init__(self, aws_access_key_id: str, aws_secret_access_key: str, region_name: str = 'us-east-1'):
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.region_name = region_name
        self.agents = self._initialize_agents()
        self.coordinator_llm = self._setup_coordinator_llm()
    
    def _setup_coordinator_llm(self) -> ChatBedrock:
        """Setup the coordinator LLM"""
        return ChatBedrock(
            model_id="anthropic.claude-3-sonnet-20240229-v1:0",
            aws_access_key_id=self.aws_access_key_id,
            aws_secret_access_key=self.aws_secret_access_key,
            region_name=self.region_name,
            model_kwargs={
                "temperature": 0.1,
                "max_tokens": 2000
            }
        )
    
    def _classify_request(self, user_input: str) -> str:
        """Classify the user request to determine which agent to use"""
        agent_types = list(self.agents.keys())
        classification_prompt = f"""
        Classify the following user request into one of these categories:
        {', '.join([f"- {agent}: {self.agents[agent].get_agent_description()}" for agent in agent_types])}
        - general: General conversation, requests that don't fit other categories
        
        User request: {user_input}
        
        Respond with only the category name ({', '.join(agent_types + ['general'])}).
        """
        
        try:
            response = self.coordinator_llm.invoke([HumanMessage(content=classification_prompt)])
            classification = response.content.strip().lower()
            
            # Check if classification matches any agent
            for agent_type in agent_types:
                if agent_type in classification:
                    return agent_type
            return "general"
        except Exception as e:
            logger.error(f"Error in request classification: {e}")
            return "general"
    
    def process_request(self, user_input: str, thread_id: str = "default") -> str:
        """Process a user request by routing to appropriate agent"""
        agent_type = self._classify_request(user_input)
        logger.info(f"Request classified as: {agent_type}")
        
        if agent_type in self.agents:
            return self.agents[agent_type].process_request(user_input, thread_id)
        else:
            # Handle general requests with coordinator
            try:
                response = self.coordinator_llm.invoke([HumanMessage(content=user_input)])
                return response.content
            except Exception as e:
                return f"I'm sorry, I encountered an error: {str(e)}"
    
    def list_agents(self) -> Dict[str, str]:
        """List all available agents"""
        agent_list = {name: agent.get_agent_description() for name, agent in self.agents.items()}
        agent_list["coordinator"] = "General conversation and request routing"
        return agent_list
    
    def get_agent_conversation_history(self, agent_type: str, thread_id: str = "default") -> List[Dict]:
        """Get conversation history for a specific agent"""
        if agent_type in self.agents:
            return self.agents[agent_type].get_conversation_history(thread_id)
        return []
    
    @abstractmethod
    def _initialize_agents(self) -> Dict[str, 'BaseAgent']:
        """Initialize all agents - to be implemented by subclasses"""
        pass
