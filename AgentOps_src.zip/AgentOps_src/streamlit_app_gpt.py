import streamlit as st
import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

BASE_URL = "http://127.0.0.1:9000/call_agentOps_agent"
HEADERS = {"Content-Type": "application/json"}

# Custom CSS
st.markdown("""
    <style>
        .stApp {
            background: linear-gradient(to right, #000080, #ff7f50);
            background-attachment: fixed;
        }

        .white-text {
            color: white !important;
        }

        .metric-box {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            text-align: center;
            margin-bottom: 20px;
        }

        .metric-label, .metric-value {
            color: white !important;
        }
    </style>
""", unsafe_allow_html=True)

st.image("header.png", use_container_width=True)

# Fetch agent counts and metadata
def fetch_counts_and_metadata():
    try:
        data_active = {"query": "provide the count of active agents"}
        response_active = requests.post(BASE_URL, headers=HEADERS, json=data_active)
        active_agents = response_active.json().get("total_active_agents", "N/A")
        agents = response_active.json().get("active_agents", [])

        agent_names = sorted([agent["name"] for agent in agents])
        agent_metadata = {agent["name"]: agent for agent in agents}

        data_all = {"query": "provide the count of registered agents"}
        response_all = requests.post(BASE_URL, headers=HEADERS, json=data_all)
        all_agents = response_all.json().get("total_agents", "N/A")

        return all_agents, active_agents, agent_names, agent_metadata
    except Exception as e:
        st.error(f"Error fetching agent data: {e}")
        return "Error", "Error", [], {}

# Fetch token usage for a selected agent
def fetch_agent_metrics(agent_name):
    try:
        data = {"query": f"get the latest token usage for the agent {agent_name}"}
        response = requests.post(BASE_URL, headers=HEADERS, json=data)
        return response.json().get("results", [{}])[0]
    except Exception as e:
        st.error(f"Error fetching metrics for {agent_name}: {e}")
        return {}

# Fetch model metrics for a selected agent
def fetch_model_metrics(agent_name):
    try:
        data = {"query": f"share the model metric of the agent {agent_name}"}
        response = requests.post(BASE_URL, headers=HEADERS, json=data)
        return response.json().get("results", [{}])[0]
    except Exception as e:
        st.error(f"Error fetching model metrics for {agent_name}: {e}")
        return {}

# Dashboard Header
st.markdown('<div class="white-text"><h2> <b>AI Agent Factory</b></h2></div>', unsafe_allow_html=True)
st.markdown('<div class="white-text"><p><b>Welcome!</b> This dashboard provides real-time insights into your registered and active agents.</p></div>', unsafe_allow_html=True)

# Fetch and store agent data
if "agent_data" not in st.session_state:
    st.session_state.agent_data = fetch_counts_and_metadata()

all_agents, active_agents, agent_names, agent_metadata = st.session_state.agent_data
# Agent Counts
col1, col2 = st.columns(2)
with col1:
    st.markdown(f"""
        <div class="metric-box">
            <div class="metric-label"><b>Registered Agents</b></div>
            <div class="metric-value">{all_agents}</div>
        </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown(f"""
        <div class="metric-box">
            <div class="metric-label"><b>Active Agents</b></div>
            <div class="metric-value">{active_agents}</div>
        </div>
    """, unsafe_allow_html=True)

# Agent selection

st.markdown("<br><br>",unsafe_allow_html=True)


st.markdown('<div class="white-text"><h3> <b>Agent Metrics</b></h3></div>', unsafe_allow_html=True)
selected_agent = st.selectbox("", agent_names)

# Display selected agent description and metrics
if selected_agent:
    agent_info = agent_metadata.get(selected_agent, {})
    # st.markdown(f'<div class="white-text"><p><b> Description:</b> {agent_info.get("desc", "No description available")}</p></div>', unsafe_allow_html=True)

    metrics = fetch_agent_metrics(selected_agent)
    input_tokens = metrics.get("total_input_tokens", 0)
    output_tokens = metrics.get("total_output_tokens", 0)
    total_requests = metrics.get("total_events", 0)
    total_cost = (input_tokens / 1_000_000) * 3 + (output_tokens / 1_000_000) * 15

    st.markdown(f"""
      <div class="metric-box">
          <div class="metric-value"><b>{selected_agent}</b></div>
          <div class="metric-value" style="font-size:18px;">{agent_info.get("desc", "No description available")}</div>
      </div>
  """, unsafe_allow_html=True)


    col1, col2 = st.columns(2)

    with col1:
        st.markdown(f"""
            <div class="metric-box">
                <div class="metric-label"><b>Total Requests</b></div>
                <div class="metric-value">{total_requests}</div>
            </div>
            <div class="metric-box">
                <div class="metric-label"><b>Input Tokens</b></div>
                <div class="metric-value">{input_tokens}</div>
            </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown(f"""
            <div class="metric-box">
                <div class="metric-label"><b>Total Cost</b></div>
                <div class="metric-value">${total_cost:.4f}</div>
            </div>
            <div class="metric-box">
                <div class="metric-label"><b>Output Tokens</b></div>
                <div class="metric-value">{output_tokens}</div>
            </div>
        """, unsafe_allow_html=True)

    st.markdown("<br><br>", unsafe_allow_html=True)

    st.markdown(f'<div class="white-text"><h4> <b>Agent Performance - {selected_agent}</b></h4></div>', unsafe_allow_html=True)
    # Dummy model metrics data
    # model_metrics = {
    #     "status": "success",
    #     "metrics": [
    #         {"metric": "InvocationLatency", "values": ["850"]},
    #         {"metric": "ModelInvocationClientErrors", "values": ["0"]},
    #         {"metric": "ModelInvocationServerErrors", "values": ["0"]}
    #     ]
    # }    
    model_metrics = fetch_model_metrics(selected_agent)





    if model_metrics.get("status") == "success":
        metric_map = {
            "InvocationLatency": "Invocation Latency (ms)",
            "ModelInvocationClientErrors": "Client Errors",
            "ModelInvocationServerErrors": "Server Errors"
        }

        col1, col2, col3 = st.columns(3)
        for metric in model_metrics.get("metrics", []):
            if metric["metric"] in metric_map:
                label = metric_map[metric["metric"]]
                latest_value = metric["values"][0] if metric["values"] else "N/A"

                with col1 if metric["metric"] == "InvocationLatency" else \
                     col2 if metric["metric"] == "ModelInvocationClientErrors" else col3:
                    st.markdown(f"""
                        <div class="metric-box">
                            <div class="metric-label"><b>{label}</b></div>
                            <div class="metric-value">{latest_value}</div>
                        </div>
                    """, unsafe_allow_html=True)
    else:
        st.error(model_metrics.get("message", "Failed to fetch model metrics"))

    # Dummy data for AWS Bedrock cost over the last 10 days
    cost_dates = pd.date_range(end=pd.Timestamp.today(), periods=10)
    cost_values = [3.06, 8.9, 12.3, 12.5, 23, 25.25, 30.96, 33.45, 35, 37]
    df_cost = pd.DataFrame({"Date": cost_dates, "Cost (USD)": cost_values})
    df_cost["Date"] = df_cost["Date"].dt.strftime('%b %d')  # Shorten date format

    # Dummy data for latency over the last 3 days
    latency_dates = pd.date_range(end=pd.Timestamp.today(), periods=3)
    latency_values = [1800 , 548, 846]
    df_latency = pd.DataFrame({"Date": latency_dates, "Latency (ms)": latency_values})
    df_latency["Date"] = df_latency["Date"].dt.strftime('%b %d')  # Shorten date format

    # Set seaborn theme
    sns.set_theme(style="whitegrid")

    # Create side-by-side plots
    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="white-text"><h4><b>Budget vs Spend</b></h4></div>', unsafe_allow_html=True)
        fig1, ax1 = plt.subplots(figsize=(6, 4))
        sns.lineplot(data=df_cost, x="Date", y="Cost (USD)", marker="o", ax=ax1, color="blue")
        ax1.axhline(y=35, color='red', linestyle='--', label='Threshold')
        ax1.set_title("Cost Over Time", fontsize=14)
        ax1.set_xlabel("Date")
        ax1.set_ylabel("Cost (USD)")
        ax1.legend()
        plt.xticks(rotation=45)
        st.pyplot(fig1)

    with col2:
        st.markdown('<div class="white-text"><h4><b>Agent Response</b></h4></div>', unsafe_allow_html=True)
        fig2, ax2 = plt.subplots(figsize=(6, 4))
        sns.lineplot(data=df_latency, x="Date", y="Latency (ms)", marker="o", ax=ax2, color="orange")
        ax2.set_title("Latency Over Time", fontsize=14)
        ax2.set_xlabel("Date")
        ax2.set_ylabel("Latency (ms)")
        plt.xticks(rotation=45)
        st.pyplot(fig2)


    # Inject custom CSS for smaller text in dataframes
    st.markdown("""
        <style>
            .alert-header {
                font-size: 16px !important;
                color: white;
            }
            div[data-testid="stDataFrame"] div {
                font-size: 10px !important;
            }
        </style>
    """, unsafe_allow_html=True)

    # Critical Alerts
    critical_alerts = [
        ["07-02 15:45","Agent Monitor", "Failure rate at 35% in the last 10 mins. Check upstream service errors or degradation."],
        ["07-02 10:06","TextAgent", "Accuracy dropped to 72% (Threshold: 85%). Possible drift or misalignment."],
        ["07-01 23:36","MathAgent", "Exceeded max response time. Latency:12.4s (Threshold: 8s). Investigate Immediately."],
        ["07-01 18:39","TextAgent", "Showing low confidence scores on 40% of queries. Consider review or retraining."],
        ["07-01 15:06","Agent Monitor", "CPU usage at 95% (avg: 65%) for last 5 mins. Scaling may be needed."]
    ]
    df_critical = pd.DataFrame(critical_alerts, columns=["Timestamp","Agent Name", "Alert Message"])


    # Warning Alerts
    warning_alerts = [
        ["07-02 12:15","Agent Monitor", "Response latency trending upward. Current: 6.2s | Baseline: 3.5s"],
        ["07-02 11:46","Agent Monitor", "Retry count increased by 60% in the last hour. Backend stability suspected."],
        ["07-02 08:30","TextAgent", "CSAT dropped to 3.2/5.0. Check recent interaction samples."],
        ["07-02 00:45","MathAgent", "Memory usage increased by 40% over 10 mins. Potential memory leak."]
    ]
    df_warning = pd.DataFrame(warning_alerts, columns=["Timestamp","Agent Name", "Alert Message"])

    # Display tables
    st.markdown("<br>", unsafe_allow_html=True)

    st.markdown('<div class="alert-header"><b> Critical Alerts</b></div>', unsafe_allow_html=True)
    st.dataframe(df_critical,hide_index=True)
    st.markdown("<br>", unsafe_allow_html=True)

    st.markdown('<div class="alert-header"><b> Warning Level Alerts</b></div>', unsafe_allow_html=True)
    st.dataframe(df_warning, hide_index=True)



