import json
import os
from typing import Dict

def load_config(config_name: str = "config") -> Dict:
    """Load configuration from file"""
    config_file_path = f"{config_name}.json"
    if os.path.exists(config_file_path):
        try:
            with open(config_file_path, 'r') as file:
                return json.load(file)
        except Exception as e:
            print(f"Error loading config file {config_file_path}: {e}")
            return {}
    else:
        print(f"Config file {config_file_path} does not exist")
        return {}

def get_aws_credentials(config_name: str = "config") -> Dict[str, str]:
    """Get AWS credentials from config or environment variables"""
    config = load_config(config_name)
    
    # For debugging
    print(f"Loaded config from {config_name}.json: {config}")
    
    credentials = {
        "aws_access_key_id": os.environ.get("AWS_ACCESS_KEY_ID", config.get("aws_access_key_id", "")),
        "aws_secret_access_key": os.environ.get("AWS_SECRET_ACCESS_KEY", config.get("aws_secret_access_key", "")),
        "region_name": os.environ.get("AWS_REGION", config.get("region_name", "us-east-1"))
    }
    
    # For debugging (don't log the actual secret in production)
    print(f"Using AWS credentials - Access Key ID: {credentials['aws_access_key_id']}, Region: {credentials['region_name']}")
    
    return credentials