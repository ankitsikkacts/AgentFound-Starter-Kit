import streamlit as st
import os
from auth import login_widget, check_access

# Custom CSS
st.markdown("""
    <style>
        .stApp {
            background: linear-gradient(to right, #000080, #ff7f50);
            background-attachment: fixed;
        }

        .white-text {
            color: white !important;
        }

        .app-card {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            text-align: center;
            margin-bottom: 20px;
            cursor: pointer;
        }

        .app-card:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
    </style>
""", unsafe_allow_html=True)

# Page title
st.markdown('<div class="white-text"><h1><b>AI Agent Factory Portal</b></h1></div>', unsafe_allow_html=True)

# Authentication check
if not login_widget():
    st.warning("Please login to access the portal")
    st.stop()

# Display available apps based on user role
st.markdown('<div class="white-text"><h2>Available Applications</h2></div>', unsafe_allow_html=True)

# Dashboard (for all users)
st.markdown("""
    <div class="app-card">
        <h3 class="white-text">Dashboard</h3>
        <p class="white-text">View agent metrics and performance analytics</p>
    </div>
""", unsafe_allow_html=True)

if st.button("Open Dashboard"):
    st.switch_page("pages/1_Dashboard.py")

# Query Interface (only for admin)
if check_access(required_role="admin"):
    st.markdown("""
        <div class="app-card">
            <h3 class="white-text">Query Interface</h3>
            <p class="white-text">Interact with AI agents</p>
        </div>
    """, unsafe_allow_html=True)
    
    if st.button("Open Query Interface"):
        st.switch_page("pages/2_Query_Interface.py")

# Display user information
st.markdown(f"""
    <div class="white-text" style="margin-top: 50px;">
        <p>Logged in as: <b>{st.session_state.username}</b> ({st.session_state.role})</p>
    </div>
""", unsafe_allow_html=True)