import streamlit as st
import hashlib
import json
import os
import time

# User database - in a real app, use a secure database
# For demo purposes, we'll use a simple JSON file
USER_DB_FILE = "users.json"
SESSION_FILE = "session.json"

def init_user_db():
    """Initialize user database if it doesn't exist"""
    if not os.path.exists(USER_DB_FILE):
        default_users = {
            "admin": {
                "password": hash_password("admin123"),
                "role": "admin"
            },
            "user": {
                "password": hash_password("user123"),
                "role": "user"
            }
        }
        with open(USER_DB_FILE, "w") as f:
            json.dump(default_users, f)

def hash_password(password):
    """Create a SHA-256 hash of the password"""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_user(username, password):
    """Verify user credentials and return role if valid"""
    try:
        with open(USER_DB_FILE, "r") as f:
            users = json.load(f)
        
        if username in users and users[username]["password"] == hash_password(password):
            return users[username]["role"]
        return None
    except Exception:
        return None

def save_session(username, role):
    """Save session to file"""
    session_data = {
        "username": username,
        "role": role,
        "timestamp": time.time(),
        "expiry": time.time() + 3600  # 1 hour expiry
    }
    with open(SESSION_FILE, "w") as f:
        json.dump(session_data, f)

def load_session():
    """Load session from file"""
    if not os.path.exists(SESSION_FILE):
        return None
    
    try:
        with open(SESSION_FILE, "r") as f:
            session_data = json.load(f)
        
        # Check if session is expired
        if session_data["expiry"] < time.time():
            os.remove(SESSION_FILE)
            return None
        
        return session_data
    except Exception:
        return None

def clear_session():
    """Clear the session file"""
    if os.path.exists(SESSION_FILE):
        os.remove(SESSION_FILE)

def login_widget():
    """Display login widget and handle authentication"""
    # Initialize session state for authentication
    if "authenticated" not in st.session_state:
        # Try to load from session file
        session_data = load_session()
        if session_data:
            st.session_state.authenticated = True
            st.session_state.username = session_data["username"]
            st.session_state.role = session_data["role"]
        else:
            st.session_state.authenticated = False
            st.session_state.username = None
            st.session_state.role = None

    # If already authenticated, show logout option
    if st.session_state.authenticated:
        st.sidebar.write(f"Logged in as: {st.session_state.username} ({st.session_state.role})")
        if st.sidebar.button("Logout"):
            st.session_state.authenticated = False
            st.session_state.username = None
            st.session_state.role = None
            clear_session()
            st.rerun()
        return True

    # Login form
    with st.sidebar.form("login_form"):
        st.write("## Login")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")

        if submit:
            # Initialize user database if needed
            init_user_db()
            
            # Verify credentials
            role = verify_user(username, password)
            if role:
                st.session_state.authenticated = True
                st.session_state.username = username
                st.session_state.role = role
                # Save session to file
                save_session(username, role)
                st.rerun()
            else:
                st.error("Invalid username or password")
    
    return st.session_state.authenticated

def check_access(required_role=None):
    """Check if user has access to a specific feature"""
    # Ensure session state is loaded from file
    if "authenticated" not in st.session_state or not st.session_state.authenticated:
        session_data = load_session()
        if session_data:
            st.session_state.authenticated = True
            st.session_state.username = session_data["username"]
            st.session_state.role = session_data["role"]
        else:
            return False
    
    if not st.session_state.authenticated:
        return False
    
    # If no specific role is required, any authenticated user has access
    if required_role is None:
        return True
    
    # Admin has access to everything
    if st.session_state.role == "admin":
        return True
    
    # Check if user's role matches required role
    return st.session_state.role == required_role