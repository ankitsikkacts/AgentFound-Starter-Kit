# conftest.py
import pytest
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure

def pytest_addoption(parser):
    """Adds --url option to pytest"""
    parser.addoption(
        "--url",
        action="store",
        default="mongodb://localhost:27017/",
        help="MongoDB connection URL",
    )

@pytest.fixture(scope="session")
def mongo_client(request):
    """
    Pytest fixture to provide a MongoDB client.
    Connects to the MongoDB URL passed via --url or default.
    """
    mongo_url = request.config.getoption("--url")
    print(f"\nConnecting to MongoDB at: {mongo_url}")
    try:
        client = MongoClient(mongo_url)
        # The ismaster command is cheap and does not require auth.
        client.admin.command('ismaster')
        print("MongoDB connection successful! 🎉")
        yield client # Provide the client to tests
    except ConnectionFailure as e:
        pytest.fail(f"MongoDB connection failed: {e}")
    finally:
        # Ensure client is closed after session
        print("Closing MongoDB client.")
        if 'client' in locals() and client: # Ensure client object exists before trying to close
            client.close()

@pytest.fixture(autouse=True)
def setup_and_teardown_db(mongo_client):
    """
    Fixture to ensure a clean 'test_agent_db' for each test function.
    This runs before and after each test.
    """
    test_db_name = "test_agent_db" # Use a distinct name for testing

    # Drop the test database before each test to ensure a clean state
    mongo_client.drop_database(test_db_name)
    print(f"Dropped database: {test_db_name}")

    yield # This is where the actual test function runs

    # Drop the test database after each test for complete isolation
    mongo_client.drop_database(test_db_name)
    print(f"Cleaned up database: {test_db_name}")
