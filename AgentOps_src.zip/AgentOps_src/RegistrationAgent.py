"""
Agent Registration implementation with versioning support
Contains agent onboarding tools and agent logic with version management.
"""

import logging
from typing import List
from datetime import datetime
from langchain_core.tools import tool
from BaseAgent import BaseAgent
from pymongo import MongoClient
from bson.json_util import dumps
import json
import boto3
from bson.objectid import ObjectId
from botocore.exceptions import ClientError

boto_client = boto3.client('logs', region_name='us-east-1')
client = MongoClient('mongodb://localhost:27017/')

# Configure logging
logger = logging.getLogger(__name__)

def get_current_timestamp():
    """Get current UTC timestamp in ISO format"""
    return datetime.utcnow().isoformat() + "Z"

def compare_agent_data(old_data, new_data):
    """Compare two agent data dictionaries and return changed fields"""
    changed_fields = []
    comparable_fields = ['name', 'arn_id', 'desc', 'status', 'created_by']
    
    for field in comparable_fields:
        if field in new_data and old_data.get(field) != new_data.get(field):
            changed_fields.append(field)
    
    return changed_fields

# Registration tools
@tool
def register_agent(agent_info: str) -> str:
    """Registers a new agent with version 1.
    Args:
        agent_info: JSON string with agent information (agent_id, name, arn_id, desc, status, created_by)
    Returns:
        Result of the agent registration operation
    """
    try:
        db = client['agent_db']
        collection = db['agents']
        
        # Validate input format
        if not agent_info or agent_info.strip() == "":
            result = {
                "status": "error",
                "message": "Agent information is required. Please provide a JSON string with agent details."
            }
            return dumps(result, separators=(',', ':'))
        
        if isinstance(agent_info, str):
            json_data = json.loads(agent_info)
        else:
            json_data = agent_info
            
        if not isinstance(json_data, dict):
            result = {
                "status": "error",
                "message": "Invalid data format. Expected a dictionary or JSON string."
            }
            return dumps(result, separators=(',', ':'))
        
        # Check if agent already exists
        existing_agent = collection.find_one({"agent_id": json_data.get("agent_id")})
        if existing_agent:
            result = {
                "status": "error",
                "message": f"Agent with ID '{json_data.get('agent_id')}' already exists"
            }
            return dumps(result, separators=(',', ':'))
        
        # Validate required fields
        required_fields = ['agent_id', 'name', 'arn_id', 'desc', 'status', 'created_by']
        for field in required_fields:
            if field not in json_data or not json_data[field]:
                result = {
                    "status": "error",
                    "message": f"Missing or empty required field: {field}"
                }
                return dumps(result, separators=(',', ':'))
        
        # Remove version from input if provided (system manages versions)
        if 'version' in json_data:
            del json_data['version']
        
        # Create new agent with version 1
        current_time = get_current_timestamp()
        agent_data = {
            "agent_id": json_data["agent_id"],
            "name": json_data["name"],
            "arn_id": json_data["arn_id"],
            "desc": json_data["desc"],
            "status": json_data["status"],
            "version_number": 1,
            "version_string": "v1",
            "max_version_number": 1,
            "is_current_version": True,
            "created_at": current_time,
            "updated_at": current_time,
            "version_created_at": current_time,
            "change_type": "create",
            "changed_fields": [],
            "previous_version_number": None,
            "rolled_back_from_version": None,
            "rollback_reason": None,
            "created_by": json_data["created_by"],
            "updated_by": json_data["created_by"],  # Initially same as created_by
            "is_deleted": False,
            "version_history": []
        }
        
        collection.insert_one(agent_data)
        
        result = {
            "status": "success",
            "message": "Agent registered successfully",
            "agent_data": agent_data
        }
        return dumps(result, separators=(',', ':'))
        
    except json.JSONDecodeError:
        result = {
            "status": "error",
            "message": "Invalid JSON format. Please provide valid JSON string."
        }
        return dumps(result, separators=(',', ':'))
    except Exception as e:
        result = {
            "status": "error",
            "message": f"Error registering agent: {str(e)}"
        }
        return dumps(result, separators=(',', ':'))

@tool
def update_agent(agent_info: str) -> str:
    """Updates agent information and increments version number only if there are changes.
    Args:
        agent_info: JSON string with complete agent information including agent_id and updated_by
    Returns:
        Result of the agent update operation
    """
    try:
        db = client['agent_db']
        collection = db['agents']
        
        # Validate input format
        if not agent_info or agent_info.strip() == "":
            result = {
                "status": "error",
                "message": "Agent information is required. Please provide a JSON string with agent details."
            }
            return dumps(result, separators=(',', ':'))
        
        # Parse updated info
        if isinstance(agent_info, str):
            update_data = json.loads(agent_info)
        else:
            update_data = agent_info
            
        if not isinstance(update_data, dict):
            result = {
                "status": "error",
                "message": "Invalid data format. Expected a dictionary or JSON string."
            }
            return dumps(result, separators=(',', ':'))
        
        # Validate required fields
        if 'agent_id' not in update_data:
            result = {
                "status": "error",
                "message": "Missing required field: agent_id"
            }
            return dumps(result, separators=(',', ':'))
        
        agent_id = update_data['agent_id']
        
        # Get current agent
        current_agent = collection.find_one({"agent_id": agent_id, "is_current_version": True})
        if not current_agent:
            result = {
                "status": "error",
                "message": f"Agent with ID '{agent_id}' not found"
            }
            return dumps(result, separators=(',', ':'))
        
        # Compare and find changed fields (exclude agent_id and updated_by from comparison)
        comparison_data = {k: v for k, v in update_data.items() if k not in ['agent_id', 'updated_by']}
        changed_fields = compare_agent_data(current_agent, comparison_data)
        
        # Remove 'created_by' from changed fields if it exists (should not be updated)
        if 'created_by' in changed_fields:
            changed_fields.remove('created_by')
        
        # If no fields changed, return success without creating new version
        if not changed_fields:
            result = {
                "status": "success",
                "message": "No changes detected. Agent remains unchanged.",
                "agent_data": current_agent
            }
            return dumps(result, separators=(',', ':'))
        
        # Create version history entry from current version
        version_history_entry = {
            "version_number": current_agent["version_number"],
            "version_string": current_agent["version_string"],
            "name": current_agent["name"],
            "arn_id": current_agent["arn_id"],
            "desc": current_agent["desc"],
            "status": current_agent["status"],
            "version_created_at": current_agent["version_created_at"],
            "change_type": current_agent["change_type"],
            "changed_fields": current_agent.get("changed_fields", []),
            "previous_version_number": current_agent.get("previous_version_number"),
            "rolled_back_from_version": current_agent.get("rolled_back_from_version"),
            "rollback_reason": current_agent.get("rollback_reason"),
            "created_by": current_agent["created_by"],
            "updated_by": current_agent.get("updated_by", current_agent["created_by"])
        }
        
        # Increment version
        new_version_number = current_agent["max_version_number"] + 1
        current_time = get_current_timestamp()
        
        # Prepare update fields
        update_fields = {
            "version_number": new_version_number,
            "version_string": f"v{new_version_number}",
            "max_version_number": new_version_number,
            "updated_at": current_time,
            "version_created_at": current_time,
            "change_type": "update",
            "changed_fields": changed_fields,
            "previous_version_number": current_agent["version_number"],
            "rolled_back_from_version": None,
            "rollback_reason": None,
            "updated_by": update_data.get("updated_by", "system")
        }
        
        # Update only the changed fields
        for field in changed_fields:
            if field in update_data and field != 'created_by':  # Never update created_by
                update_fields[field] = update_data[field]
        
        # Add current version to history
        current_history = current_agent.get("version_history", [])
        current_history.append(version_history_entry)
        update_fields["version_history"] = current_history
        
        # Update the document
        collection.update_one(
            {"agent_id": agent_id, "is_current_version": True},
            {"$set": update_fields}
        )
        
        # Get updated agent
        updated_agent = collection.find_one({"agent_id": agent_id, "is_current_version": True})
        
        result = {
            "status": "success",
            "message": f"Agent '{agent_id}' updated to version {new_version_number}. Changed fields: {', '.join(changed_fields)}",
            "agent_data": updated_agent
        }
        return dumps(result, separators=(',', ':'))
        
    except json.JSONDecodeError:
        result = {
            "status": "error",
            "message": "Invalid JSON format. Please provide valid JSON string."
        }
        return dumps(result, separators=(',', ':'))
    except Exception as e:
        result = {
            "status": "error",
            "message": f"Error updating agent: {str(e)}"
        }
        return dumps(result, separators=(',', ':'))

@tool
def update_agent_status(agent_id: str, status: str, updated_by: str) -> str:
    """Updates only the status of an agent without incrementing version.
    Args:
        agent_id: The ID of the agent to update
        status: The new status ('Active' or 'Inactive')
        updated_by: User making the status change
    Returns:
        Result of the status update operation
    """
    try:
        db = client['agent_db']
        collection = db['agents']
        
        # Validate status input
        if status not in ['Active', 'Inactive']:
            result = {
                "status": "error",
                "message": "Invalid status. Must be 'Active' or 'Inactive'"
            }
            return dumps(result, separators=(',', ':'))
        
        # Check if agent exists
        agent = collection.find_one({"agent_id": agent_id, "is_current_version": True})
        if not agent:
            result = {
                "status": "error",
                "message": f"Agent with ID '{agent_id}' not found"
            }
            return dumps(result, separators=(',', ':'))
        
        # Check if status is actually changing
        if agent["status"] == status:
            result = {
                "status": "success",
                "message": f"Agent '{agent_id}' status is already '{status}'. No changes made.",
                "agent_data": agent
            }
            return dumps(result, separators=(',', ':'))
        
        # Update only status, updated_at, and updated_by
        update_result = collection.update_one(
            {"agent_id": agent_id, "is_current_version": True},
            {"$set": {
                "status": status,
                "updated_at": get_current_timestamp(),
                "updated_by": updated_by
            }}
        )
        
        if update_result.modified_count > 0:
            updated_agent = collection.find_one({"agent_id": agent_id, "is_current_version": True})
            result = {
                "status": "success",
                "message": f"Agent '{agent_id}' status updated to '{status}'",
                "agent_data": updated_agent
            }
        else:
            result = {
                "status": "error",
                "message": f"Failed to update agent '{agent_id}' status"
            }
        
        return dumps(result, separators=(',', ':'))
        
    except Exception as e:
        result = {
            "status": "error",
            "message": f"Error updating agent status: {str(e)}"
        }
        return dumps(result, separators=(',', ':'))

@tool
def rollback_agent_version(agent_id: str, target_version: int, rollback_reason: str, updated_by: str) -> str:
    """Rolls back an agent to a specific version.
    Args:
        agent_id: The ID of the agent to rollback
        target_version: The version number to rollback to
        rollback_reason: Reason for the rollback
        updated_by: User performing the rollback
    Returns:
        Result of the rollback operation
    """
    try:
        db = client['agent_db']
        collection = db['agents']
        
        # Get current agent
        current_agent = collection.find_one({"agent_id": agent_id, "is_current_version": True})
        if not current_agent:
            result = {
                "status": "error",
                "message": f"Agent with ID '{agent_id}' not found"
            }
            return dumps(result, separators=(',', ':'))
        
        # Check if target version exists in history
        target_version_data = None
        for version in current_agent.get("version_history", []):
            if version["version_number"] == target_version:
                target_version_data = version
                break
        
        if not target_version_data:
            result = {
                "status": "error",
                "message": f"Version {target_version} not found in agent history"
            }
            return dumps(result, separators=(',', ':'))
        
        # Check if already at target version
        if current_agent["version_number"] == target_version:
            result = {
                "status": "success",
                "message": f"Agent '{agent_id}' is already at version {target_version}. No rollback needed.",
                "agent_data": current_agent
            }
            return dumps(result, separators=(',', ':'))
        
        # Create version history entry from current version
        version_history_entry = {
            "version_number": current_agent["version_number"],
            "version_string": current_agent["version_string"],
            "name": current_agent["name"],
            "arn_id": current_agent["arn_id"],
            "desc": current_agent["desc"],
            "status": current_agent["status"],
            "version_created_at": current_agent["version_created_at"],
            "change_type": current_agent["change_type"],
            "changed_fields": current_agent.get("changed_fields", []),
            "previous_version_number": current_agent.get("previous_version_number"),
            "rolled_back_from_version": current_agent.get("rolled_back_from_version"),
            "rollback_reason": current_agent.get("rollback_reason"),
            "created_by": current_agent["created_by"],
            "updated_by": current_agent.get("updated_by", current_agent["created_by"])
        }
        
        # Calculate changed fields
        changed_fields = compare_agent_data(current_agent, target_version_data)
        # Remove 'created_by' from changed fields if it exists (should not be updated)
        if 'created_by' in changed_fields:
            changed_fields.remove('created_by')
        
        current_time = get_current_timestamp()
        
        # Update agent with rolled back version
        update_fields = {
            "name": target_version_data["name"],
            "arn_id": target_version_data["arn_id"],
            "desc": target_version_data["desc"],
            "status": target_version_data["status"],
            "version_number": target_version,
            "version_string": f"v{target_version}",
            "updated_at": current_time,
            "version_created_at": current_time,
            "change_type": "rollback",
            "changed_fields": changed_fields,
            "previous_version_number": current_agent["version_number"],
            "rolled_back_from_version": current_agent["version_number"],
            "rollback_reason": rollback_reason,
            "updated_by": updated_by
            # Note: created_by remains unchanged (preserved from original)
        }
        
        # Add current version to history
        current_history = current_agent.get("version_history", [])
        current_history.append(version_history_entry)
        update_fields["version_history"] = current_history
        
        # Update the document
        collection.update_one(
            {"agent_id": agent_id, "is_current_version": True},
            {"$set": update_fields}
        )
        
        # Get updated agent
        updated_agent = collection.find_one({"agent_id": agent_id, "is_current_version": True})
        
        result = {
            "status": "success",
            "message": f"Agent '{agent_id}' rolled back to version {target_version}",
            "agent_data": updated_agent
        }
        return dumps(result, separators=(',', ':'))
        
    except Exception as e:
        result = {
            "status": "error",
            "message": f"Error rolling back agent: {str(e)}"
        }
        return dumps(result, separators=(',', ':'))

@tool
def get_agent_version_history(agent_id: str) -> str:
    """Gets the version history of an agent.
    Args:
        agent_id: The ID of the agent
    Returns:
        Version history of the agent
    """
    try:
        db = client['agent_db']
        collection = db['agents']
        
        agent = collection.find_one({"agent_id": agent_id, "is_current_version": True})
        if not agent:
            result = {
                "status": "error",
                "message": f"Agent with ID '{agent_id}' not found"
            }
            return dumps(result, separators=(',', ':'))
        
        # Include current version in history
        current_version = {
            "version_number": agent["version_number"],
            "version_string": agent["version_string"],
            "name": agent["name"],
            "arn_id": agent["arn_id"],
            "desc": agent["desc"],
            "status": agent["status"],
            "version_created_at": agent["version_created_at"],
            "change_type": agent["change_type"],
            "changed_fields": agent.get("changed_fields", []),
            "previous_version_number": agent.get("previous_version_number"),
            "rolled_back_from_version": agent.get("rolled_back_from_version"),
            "rollback_reason": agent.get("rollback_reason"),
            "created_by": agent["created_by"],
            "updated_by": agent.get("updated_by", agent["created_by"]),
            "is_current": True
        }
        
        version_history = agent.get("version_history", [])
        for version in version_history:
            version["is_current"] = False
        
        all_versions = version_history + [current_version]
        all_versions.sort(key=lambda x: x["version_number"])
        
        result = {
            "status": "success",
            "agent_id": agent_id,
            "current_version": agent["version_number"],
            "max_version": agent["max_version_number"],
            "total_versions": len(all_versions),
            "version_history": all_versions
        }
        return dumps(result, separators=(',', ':'))
        
    except Exception as e:
        result = {
            "status": "error",
            "message": f"Error retrieving version history: {str(e)}"
        }
        return dumps(result, separators=(',', ':'))

@tool
def get_agent_by_version(agent_id: str, version_number: int) -> str:
    """Gets a specific version of an agent.
    Args:
        agent_id: The ID of the agent
        version_number: The version number to retrieve
    Returns:
        Specific version of the agent
    """
    try:
        db = client['agent_db']
        collection = db['agents']
        
        agent = collection.find_one({"agent_id": agent_id, "is_current_version": True})
        if not agent:
            result = {
                "status": "error",
                "message": f"Agent with ID '{agent_id}' not found"
            }
            return dumps(result, separators=(',', ':'))
        
        # Check if it's the current version
        if agent["version_number"] == version_number:
            result = {
                "status": "success",
                "agent_data": agent,
                "is_current_version": True
            }
            return dumps(result, separators=(',', ':'))
        
        # Look in version history
        for version in agent.get("version_history", []):
            if version["version_number"] == version_number:
                result = {
                    "status": "success",
                    "agent_data": version,
                    "is_current_version": False
                }
                return dumps(result, separators=(',', ':'))
        
        result = {
            "status": "error",
            "message": f"Version {version_number} not found for agent '{agent_id}'"
        }
        return dumps(result, separators=(',', ':'))
        
    except Exception as e:
        result = {
            "status": "error",
            "message": f"Error retrieving agent version: {str(e)}"
        }
        return dumps(result, separators=(',', ':'))

@tool
def view_all_registered_agents() -> str:
    """Returns the list of all current versions of registered agents.
    Returns:
        List of all current agent versions
    """
    try:
        db = client['agent_db']
        collection = db['agents']
        
        all_agents = list(collection.find({}))
#        all_agents = list(collection.find({"is_current_version": True, "is_deleted": False}))
        
        result = {
            "status": "success",
            "total_agents": len(all_agents),
            "agents": all_agents
        }
        return dumps(result, separators=(',', ':'))
        
    except Exception as e:
        result = {
            "status": "error",
            "message": f"Error retrieving agents: {str(e)}"
        }
        return dumps(result, separators=(',', ':'))

@tool
def view_all_active_agents() -> str:
    """Returns the list of all active agents.
    Returns:
        List of all active agents
    """
    try:
        db = client['agent_db']
        collection = db['agents']
        
        active_agents = list(collection.find({
            "status": "Active",
#            "is_current_version": True,
            # "is_deleted": False
        }))
        
        result = {
            "status": "success",
            "total_active_agents": len(active_agents),
            "active_agents": active_agents
        }
        return dumps(result, separators=(',', ':'))
        
    except Exception as e:
        result = {
            "status": "error",
            "message": f"Error retrieving active agents: {str(e)}"
        }
        return dumps(result, separators=(',', ':'))

class RegistrationAgent(BaseAgent):
    """Registration agent with versioning support for managing Agentic AI agents"""
    
    def _requires_json_only(self) -> bool:
        """This agent requires JSON-only responses"""
        return True
    
    def _get_tools(self) -> List:
        """Return registration-specific tools with versioning support"""
        return [
            register_agent,
            update_agent,
            update_agent_status,
            rollback_agent_version,
            get_agent_version_history,
            get_agent_by_version,
            view_all_registered_agents,
            view_all_active_agents,
        ]
    
    def _get_system_message(self) -> str:
        """Return agent-registration specific system message"""
        return """You are a JSON-only agent registration system with versioning support. You must respond EXCLUSIVELY with the JSON output from tools - NO additional text.

Available tools:
- register_agent(agent_info): Registers new agent with v1 (requires complete JSON: agent_id, name, arn_id, desc, status, created_by)
- update_agent(agent_info): Updates the already existing agent with complete JSON and increments version only for changed fields
- update_agent_status(agent_id, status, updated_by): Updates only status without version increment
- rollback_agent_version(agent_id, target_version, rollback_reason, updated_by): Rolls back to specific version
- get_agent_version_history(agent_id): Gets complete version history fo an agent
- get_agent_by_version(agent_id, version_number): Gets specific version of an agent by version number
- view_all_registered_agents(): Provides the lists of all current agent versions
- view_all_active_agents(): Provides the lists of all active agents

VERSIONING RULES:
- Version increments ONLY when fields actually change (name, arn_id, desc, status)
- created_by field is IMMUTABLE after creation
- updated_by tracks who made each change
- Version does NOT increment for: status-only changes via update_agent_status
- Rollback restores ALL fields to target version
- All versions are preserved in history

CRITICAL: 
- Use tools to get JSON responses
- Return ONLY the tool's JSON output
- DO NOT ASSUME any information at the time of modifciation/updation of an agent.
- NO explanations or summaries
- DO NOT compile responses of multiple requests
- Complete JSON required for all operations

Return tool JSON output directly."""
    
    def get_agent_description(self) -> str:
        """Return description of agent registration capabilities"""
        return "Agent Registration system with versioning support (registration, updates, rollbacks, version history, status management, count of registered agents , count of agents with status active, status of agents)"
