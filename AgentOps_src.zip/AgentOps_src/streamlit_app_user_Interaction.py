import streamlit as st
import requests

# Constants
BASE_URL = "http://127.0.0.1:5000/call_agentOps_agent"  # Replace with your actual FastAPI endpoint
HEADERS = {"Content-Type": "application/json"}

# Streamlit UI

st.markdown("<h1 style='font-size: 2.25em;'>Agent Foundry - AgentOps - Query</h1>", unsafe_allow_html=True)


# Input box
query = st.text_input("Enter your query:")

# Submit button
if st.button("Submit"):
    if query.strip():
        # Clear previous output
        st.empty()

        # Show loading spinner
        with st.spinner("Waiting for response..."):
            data = {"query": query}
            try:
                response = requests.post(BASE_URL, headers=HEADERS, json=data)
                if response.status_code == 200:
                    result = response.json()
                    st.success("Response received:")
                    st.write(result)
                else:
                    st.error(f"Error {response.status_code}: {response.text}")
            except Exception as e:
                st.error(f"Request failed: {e}")
    else:
        st.warning("Please enter a query before submitting.")
