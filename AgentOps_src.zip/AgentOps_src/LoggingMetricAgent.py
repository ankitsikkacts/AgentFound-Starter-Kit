""" Enhanced Logging Metric implementation with MongoDB support
Groups Bedrock model invocation logs by ARN user into respective collections in MongoDB
VERSION: Added agent lookup functionality to get ARN ID from agent database """

import logging
from typing import List, Dict, Optional
from langchain_core.tools import tool
from BaseAgent import BaseAgent
import json
from botocore.exceptions import ClientError, BotoCoreError
import boto3
import hashlib
import time
from datetime import datetime, timedelta, timezone
import re
import os
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.errors import DuplicateKeyError, PyMongoError

# Database configuration
MONGO_URI = "mongodb://localhost:27017/" # Default MongoDB URI for local instance
LOGS_DATABASE_NAME = "bedrock_analytics"
AGENT_DATABASE_NAME = "agent_db"
AGENT_COLLECTION = "agents" # Agent registration collection
LOGS_COLLECTION_PREFIX = "bedrock_logs_" # Prefix for user-specific collections
METADATA_COLLECTION = "sync_metadata"
GLOBAL_METADATA_COLLECTION = "global_sync_metadata"

BEDROCK_LOG_GROUP = '/aws/bedrock/model-invocations'
REGION = 'us-east-1'

# Configure logging
logger = logging.getLogger(__name__)

# Add a credentials manager at the module level
class CredentialsManager:
    """Simple class to manage AWS credentials at module level"""
    aws_access_key_id = None
    aws_secret_access_key = None
    region_name = 'us-east-1'

# Create a singleton instance
credentials = CredentialsManager()

# MongoDB connection pooling
_mongo_client = None

def get_mongo_client():
    """Get or create a shared MongoDB client"""
    global _mongo_client
    if _mongo_client is None:
        _mongo_client = MongoClient(MONGO_URI)
    return _mongo_client

# Common utilities
def handle_tool_error(func_name, e, **context):
    """Standard error handling for tool functions"""
    logger.error(f"Error in {func_name}: {str(e)}")
    logger.exception("Full exception:")
    return json.dumps({
        "status": "error",
        "message": f"Error in {func_name}: {str(e)}",
        **context
    })

def find_agent_by_name(agent_name):
    """Utility to find agent by name in MongoDB"""
    client = get_mongo_client()
    agent_db = client[AGENT_DATABASE_NAME]
    agent_collection = agent_db[AGENT_COLLECTION]
    
    # Log all agents for debugging
    all_agents = list(agent_collection.find())
    logger.info(f"All agents in database: {all_agents}")
    
    # Try exact match first (case-insensitive)
    for doc in all_agents:
        if doc.get('name', '').lower() == agent_name.lower() or doc.get('agent_id', '').lower() == agent_name.lower():
            logger.info(f"Found agent match: {doc}")
            return doc
            
    # Try partial match as fallback
    for doc in all_agents:
        if agent_name.lower() in doc.get('name', '').lower() or agent_name.lower() in doc.get('agent_id', '').lower():
            logger.info(f"Found partial agent match: {doc}")
            return doc
            
    return None

def normalize_arn_id(arn_id):
    """Normalize ARN ID for collection name"""
    normalized = arn_id.lower().replace('.', '-').replace('_', '-')
    return re.sub(r'[^a-z0-9-]', '', normalized)

def aggregate_token_usage(collection):
    """Aggregate token usage data from a MongoDB collection"""
    # Fetch the documents with projection to get only needed fields
    documents = list(collection.find({}, {
        "input_tokens": 1, 
        "output_tokens": 1, 
        "total_tokens": 1, 
        "model_id": 1, 
        "timestamp": 1
    }))
    
    # Manual aggregation in Python
    total_events = len(documents)
    total_input_tokens = sum(doc.get("input_tokens", 0) for doc in documents)
    total_output_tokens = sum(doc.get("output_tokens", 0) for doc in documents)
    total_tokens = sum(doc.get("total_tokens", 0) for doc in documents)
    
    # Get unique models
    unique_models = set()
    for doc in documents:
        model_id = doc.get("model_id")
        if model_id:
            unique_models.add(model_id)
    
    # Find first and last event timestamps
    first_event = None
    last_event = None
    for doc in documents:
        timestamp = doc.get("timestamp")
        if timestamp:
            if first_event is None or timestamp < first_event:
                first_event = timestamp
            if last_event is None or timestamp > last_event:
                last_event = timestamp
    
    return {
        "total_events": total_events,
        "total_input_tokens": total_input_tokens,
        "total_output_tokens": total_output_tokens,
        "total_tokens": total_tokens,
        "unique_models": list(unique_models),
        "first_event": first_event,
        "last_event": last_event
    }

def extract_model_ids_from_logs(collection):
    """Extract all model IDs from logs collection"""
    model_ids = set()
    
    # Get all documents with projection to retrieve only needed fields
    documents = list(collection.find({}, {"model_id": 1, "parsed_data": 1}))
    
    for doc in documents:
        # Extract model_id field
        model_id = doc.get("model_id")
        if model_id is not None:
            model_ids.add(model_id)
        
        # Extract modelId from parsed_data
        parsed_data = doc.get("parsed_data", {})
        if isinstance(parsed_data, dict) and "modelId" in parsed_data:
            model_id = parsed_data.get("modelId")
            if model_id is not None:
                model_ids.add(model_id)
    
    return list(model_ids)

# BedrockLogsManager class (simplified to only handle log syncing)
class BedrockLogsManager:
    def __init__(self, aws_access_key_id=None, aws_secret_access_key=None, region_name='us-east-1'):
        self.region_name = region_name
        self.client = get_mongo_client()
        self.logs_db = self.client[LOGS_DATABASE_NAME]
        self.agent_db = self.client[AGENT_DATABASE_NAME]
        
        # Use credentials if provided
        if aws_access_key_id and aws_secret_access_key:
            self.cloudwatch_client = boto3.client(
                'logs', 
                region_name=region_name,
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key
            )
        else:
            self.cloudwatch_client = boto3.client('logs', region_name=region_name)
            
        self.log_group_name = BEDROCK_LOG_GROUP
        self.start_date = datetime(2025, 7, 23)

    def extract_user_id_from_arn(self, arn: str) -> Optional[str]:
        """
        Extract user ID from ARN format
        Examples:
        - "arn:aws:iam::345208593967:user/Sushmita.Sahu" -> "sushmita-sahu"
        - "arn:aws:iam::345208593967:user/agentops-iam-user" -> "agentops-iam-user"
        """
        try:
            if ':user/' in arn:
                user_id = arn.split(':user/')[-1]
                return user_id.lower().replace('.', '-')  # Normalize for collection names
            return None
        except Exception as e:
            logger.error(f"Error extracting user ID from ARN {arn}: {e}")
            return None

    def get_user_logs_collection(self, user_id: str):
        """Get user-specific logs collection"""
        normalized_user_id = normalize_arn_id(user_id)
        collection_name = f"{LOGS_COLLECTION_PREFIX}{normalized_user_id}"
        collection = self.logs_db[collection_name]
        
        # Create indexes for the user collection
        try:
            collection.create_index([("event_id", ASCENDING)], unique=True)
            collection.create_index([("timestamp_ms", DESCENDING)])
            collection.create_index([("model_id", ASCENDING)])
            collection.create_index([("request_id", ASCENDING)])
        except Exception as e:
            logger.debug(f"Index creation skipped for {collection_name}: {e}")
            
        return collection

    def get_metadata_collection(self):
        """Get metadata collection"""
        return self.logs_db[METADATA_COLLECTION]

    def get_global_metadata_collection(self):
        """Get global metadata collection for tracking overall sync progress"""
        return self.logs_db[GLOBAL_METADATA_COLLECTION]

    def generate_event_id(self, timestamp: int, request_id: str, message: str) -> str:
        """Generate unique event ID from timestamp, request ID, and message"""
        unique_string = f"{timestamp}_{request_id}_{message[:100]}"  # Limit message length
        return hashlib.md5(unique_string.encode()).hexdigest()

    def get_global_last_processed_timestamp(self) -> datetime:
        """Get the global last processed timestamp for incremental sync"""
        try:
            global_metadata_collection = self.get_global_metadata_collection()
            result = global_metadata_collection.find_one({"sync_type": "bedrock_logs"})
            
            if result and result.get('last_processed_timestamp'):
                last_timestamp_str = result['last_processed_timestamp']
                # Handle both ISO format with and without timezone
                if last_timestamp_str.endswith('Z'):
                    last_timestamp_str = last_timestamp_str.replace('Z', '+00:00')
                elif '+00:00' not in last_timestamp_str and 'T' in last_timestamp_str:
                    last_timestamp_str = last_timestamp_str + '+00:00'
                
                return datetime.fromisoformat(last_timestamp_str)
            
            return self.start_date.replace(tzinfo=timezone.utc)
        except Exception as e:
            logger.error(f"Error reading global metadata: {e}")
            return self.start_date.replace(tzinfo=timezone.utc)

    def update_global_metadata(self, last_processed_timestamp: datetime, events_count: int):
        """Update global metadata with latest sync information"""
        metadata = {
            "sync_type": "bedrock_logs",
            "log_group_name": self.log_group_name,
            "last_processed_timestamp": last_processed_timestamp.isoformat(),
            "last_sync_time": datetime.utcnow().replace(tzinfo=timezone.utc).isoformat(),
            "total_events_processed": events_count
        }
        
        global_metadata_collection = self.get_global_metadata_collection()
        
        # Update or insert metadata
        global_metadata_collection.replace_one(
            {"sync_type": "bedrock_logs"},
            metadata,
            upsert=True
        )

    def get_last_processed_timestamp(self, collection_name: str) -> datetime:
        """Get last processed timestamp from user-specific metadata"""
        try:
            metadata_collection = self.get_metadata_collection()
            result = metadata_collection.find_one({"collection_name": collection_name})
            
            if result and result.get('last_processed_timestamp'):
                last_timestamp_str = result['last_processed_timestamp']
                if last_timestamp_str.endswith('Z'):
                    last_timestamp_str = last_timestamp_str.replace('Z', '+00:00')
                elif '+00:00' not in last_timestamp_str and 'T' in last_timestamp_str:
                    last_timestamp_str = last_timestamp_str + '+00:00'
                
                return datetime.fromisoformat(last_timestamp_str)
            
            return self.start_date.replace(tzinfo=timezone.utc)
        except Exception as e:
            logger.error(f"Error reading metadata for {collection_name}: {e}")
            return self.start_date.replace(tzinfo=timezone.utc)

    def update_metadata(self, collection_name: str, last_processed_timestamp: datetime, events_count: int):
        """Update metadata with latest sync information"""
        metadata = {
            "collection_name": collection_name,
            "log_group_name": self.log_group_name,
            "last_processed_timestamp": last_processed_timestamp.isoformat(),
            "last_sync_time": datetime.utcnow().replace(tzinfo=timezone.utc).isoformat(),
            "total_events_processed": events_count
        }
        
        metadata_collection = self.get_metadata_collection()
        
        # Update or insert metadata
        metadata_collection.replace_one(
            {"collection_name": collection_name},
            metadata,
            upsert=True
        )

    def fetch_bedrock_events(self, start_time: datetime, end_time: datetime) -> List[Dict]:
        """Fetch events from Bedrock CloudWatch logs"""
        events = []
        next_token = None
        request_count = 0
        
        start_time_ms = int(start_time.timestamp() * 1000)
        end_time_ms = int(end_time.timestamp() * 1000)
        
        print(f"Fetching Bedrock events from {start_time.strftime('%Y-%m-%d %H:%M:%S')} to {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        while True:
            request_count += 1
            
            try:
                kwargs = {
                    'logGroupName': self.log_group_name,
                    'startTime': start_time_ms,
                    'endTime': end_time_ms,
                    'limit': 10000  # Maximum events per request
                }
                
                if next_token:
                    kwargs['nextToken'] = next_token
                
                print(f"  API Request {request_count}: ", end="", flush=True)
                
                response = self.cloudwatch_client.filter_log_events(**kwargs)
                batch_events = response.get('events', [])
                
                print(f"{len(batch_events)} events (total: {len(events) + len(batch_events)})")
                
                if batch_events:
                    events.extend(batch_events)
                
                next_token = response.get('nextToken')
                if not next_token:
                    break
                
                # Rate limiting
                time.sleep(0.5)
                
            except ClientError as e:
                error_code = e.response.get('Error', {}).get('Code', '')
                if error_code == 'ThrottlingException':
                    print(f"  Throttled, waiting 2 seconds...")
                    time.sleep(2)
                    continue
                elif error_code == 'ResourceNotFoundException':
                    print(f"  Log group '{self.log_group_name}' not found")
                    break
                else:
                    print(f"  CloudWatch API Error: {e}")
                    raise
            except Exception as e:
                print(f"  Unexpected error: {e}")
                raise
        
        print(f"Total Bedrock events fetched: {len(events)} in {request_count} requests")
        return events

    def parse_bedrock_log_message(self, message: str) -> Optional[Dict]:
        """Parse Bedrock log message to extract structured data with enhanced debugging"""
        try:
            # Skip empty or whitespace-only messages
            if not message or not message.strip():
                logger.debug("Skipped: Empty message")
                return None
            
            # Try to parse JSON message
            try:
                log_data = json.loads(message.strip())
            except json.JSONDecodeError as e:
                logger.warning(f"JSON decode failed for message: {message[:200]}... Error: {e}")
                return None
            
            # Ensure we have a valid dictionary
            if not isinstance(log_data, dict):
                logger.warning(f"Message is not a dict: {type(log_data)}")
                return None
            
            # Extract user ID from ARN with enhanced debugging
            user_id = None
            user_arn = None
            
            if 'identity' in log_data and isinstance(log_data['identity'], dict):
                if 'arn' in log_data['identity']:
                    user_arn = log_data['identity']['arn']
                    user_id = self.extract_user_id_from_arn(user_arn)
                    if not user_id:
                        logger.warning(f"Failed to extract user ID from ARN: {user_arn}")
                else:
                    logger.warning(f"No 'arn' in identity: {log_data['identity'].keys()}")
            else:
                logger.warning(f"No 'identity' in log_data. Available keys: {log_data.keys()}")
                # Log a sample of the problematic message for analysis
                logger.warning(f"Sample problematic message: {json.dumps(log_data, indent=2)[:500]}...")
            
            # Skip if we can't identify the user
            if not user_id:
                logger.warning(f"Skipping event - no user_id extracted. ARN: {user_arn}")
                return None
            
            # Extract token usage information from various possible locations
            input_tokens = 0
            output_tokens = 0
            
            # Check input section
            if 'input' in log_data and isinstance(log_data['input'], dict):
                input_tokens = log_data['input'].get('inputTokenCount', 0)
            
            # Check output section  
            if 'output' in log_data and isinstance(log_data['output'], dict):
                output_tokens = log_data['output'].get('outputTokenCount', 0)
            
            # Check usage section (alternative location)
            if 'usage' in log_data and isinstance(log_data['usage'], dict):
                usage = log_data['usage']
                input_tokens = usage.get('inputTokens', input_tokens)
                output_tokens = usage.get('outputTokens', output_tokens)
            
            # Check for additional token count locations
            if 'metrics' in log_data and isinstance(log_data['metrics'], dict):
                metrics = log_data['metrics']
                input_tokens = metrics.get('inputTokenCount', input_tokens)
                output_tokens = metrics.get('outputTokenCount', output_tokens)
            
            logger.debug(f"Successfully parsed event for user: {user_id}")
            
            return {
                'user_id': user_id,
                'user_arn': user_arn,
                'account_id': log_data.get('accountId'),
                'region': log_data.get('region'),
                'request_id': log_data.get('requestId', ''),
                'operation': log_data.get('operation'),
                'model_id': log_data.get('modelId'),
                'input_tokens': int(input_tokens) if input_tokens else 0,
                'output_tokens': int(output_tokens) if output_tokens else 0,
                'total_tokens': int(input_tokens) + int(output_tokens) if input_tokens or output_tokens else 0,
                'raw_log': log_data
            }
            
        except Exception as e:
            logger.error(f"Unexpected error parsing message: {e}")
            logger.error(f"Problematic message: {message[:200]}...")
            return None

    def process_and_store_events(self, events: List[Dict]):
        """Process Bedrock events and store in user-specific collections grouped by ARN"""
        if not events:
            print("No events to process")
            return
        
        user_events = {}  # user_id -> list of events
        processed_count = 0
        skipped_count = 0
        latest_timestamp = None
        
        print(f"Processing {len(events)} Bedrock events...")
        
        for event in events:
            try:
                timestamp = datetime.fromtimestamp(event['timestamp'] / 1000, tz=timezone.utc)
                message = event.get('message', '')
                
                # Track the latest timestamp for global metadata
                if latest_timestamp is None or timestamp > latest_timestamp:
                    latest_timestamp = timestamp
                
                # Parse Bedrock log message
                parsed_data = self.parse_bedrock_log_message(message)
                if not parsed_data or not parsed_data['user_id']:
                    skipped_count += 1
                    continue
                
                user_id = parsed_data['user_id']
                request_id = parsed_data['request_id']
                
                # Generate unique event ID
                event_id = self.generate_event_id(event['timestamp'], request_id, message)
                
                # Prepare event data
                processed_event = {
                    'event_id': event_id,
                    'timestamp': timestamp.isoformat(),
                    'timestamp_ms': event['timestamp'],
                    'user_id': user_id,
                    'user_arn': parsed_data['user_arn'],
                    'account_id': parsed_data['account_id'],
                    'region': parsed_data['region'],
                    'request_id': request_id,
                    'operation': parsed_data['operation'],
                    'model_id': parsed_data['model_id'],
                    'input_tokens': parsed_data['input_tokens'],
                    'output_tokens': parsed_data['output_tokens'],
                    'total_tokens': parsed_data['total_tokens'],
                    'log_stream_name': event.get('logStreamName', ''),
                    'raw_message': message,
                    'parsed_data': parsed_data['raw_log']
                }
                
                # Group by user ID
                if user_id not in user_events:
                    user_events[user_id] = []
                user_events[user_id].append(processed_event)
                processed_count += 1
                
            except Exception as e:
                logger.error(f"Error processing event: {e}")
                skipped_count += 1
                continue
        
        print(f"Successfully processed {processed_count} events for {len(user_events)} users (skipped {skipped_count})")
        
        # Store events in user-specific collections
        total_new_events = 0
        for user_id, events_list in user_events.items():
            try:
                user_collection = self.get_user_logs_collection(user_id)
                
                # Insert events, handling duplicates
                new_events_count = 0
                for event in events_list:
                    try:
                        user_collection.insert_one(event)
                        new_events_count += 1
                    except DuplicateKeyError:
                        # Skip duplicate events
                        continue
                
                if new_events_count > 0:
                    total_new_events += new_events_count
                    print(f"Inserted {new_events_count} new events for user collection: {user_id}")
                    
                    # Update metadata for user collection
                    latest_user_timestamp = max(
                        datetime.fromisoformat(event['timestamp'])
                        for event in events_list
                    )
                    current_count = user_collection.count_documents({})
                    collection_name = f"{LOGS_COLLECTION_PREFIX}{user_id}"
                    self.update_metadata(collection_name, latest_user_timestamp, current_count)
                else:
                    print(f"No new events for user: {user_id}")
                    
            except Exception as e:
                logger.error(f"Error storing events for user {user_id}: {e}")
        
        # Update global metadata with the latest timestamp
        if latest_timestamp and total_new_events > 0:
            self.update_global_metadata(latest_timestamp, total_new_events)
            print(f"Updated global metadata with timestamp: {latest_timestamp}")

    def sync_bedrock_logs(self):
        """Main sync function for Bedrock logs with improved incremental logic"""
        print(f"=== Syncing Bedrock Model Invocation Logs ===")
        
        try:
            # Get global last processed timestamp for incremental sync
            last_timestamp = self.get_global_last_processed_timestamp()
            current_time = datetime.utcnow().replace(tzinfo=timezone.utc)
            
            print(f"Last processed: {last_timestamp}")
            print(f"Current time: {current_time}")
            
            # Check if sync is needed (allow small buffer for edge cases)
            time_diff = current_time - last_timestamp
            if time_diff.total_seconds() < 60:  # Less than 1 minute
                print("No new events to sync (less than 1 minute since last sync)")
                return
            
            # Fetch events from CloudWatch starting after the last processed timestamp
            start_time = last_timestamp + timedelta(milliseconds=1)
            events = self.fetch_bedrock_events(start_time, current_time)
            
            if not events:
                print("No new events found in the specified time range")
                return
            
            # Process and store events
            self.process_and_store_events(events)
            
            print(f"=== Bedrock Logs Sync Complete ===\n")
            
        except Exception as e:
            print(f"Sync failed: {e}")
            logger.error(f"Sync failed: {e}")
            raise

# Tool implementations using shared utilities
@tool
def get_agent_arn_id_by_name(agent_name: str):
    """Get ARN ID for a specific agent name from the agent database"""
    try:
        agent = find_agent_by_name(agent_name)
        
        if not agent:
            return json.dumps({
                "status": "error",
                "agent_name": agent_name,
                "message": f"Agent '{agent_name}' not found in agent database"
            })
        
        # Get the ARN ID for the agent
        arn_id = agent.get('arn_id')
        
        return json.dumps({
            "status": "success",
            "agent_name": agent_name,
            "arn_id": arn_id
        })
        
    except Exception as e:
        return handle_tool_error("get_agent_arn_id_by_name", e, agent_name=agent_name)

@tool
def get_agent_token_usage_by_name(agent_name: str):
    """Get token usage statistics for a specific agent by name"""
    try:
        # Step 1: Find the agent by name
        agent = find_agent_by_name(agent_name)
        
        if not agent:
            return json.dumps({
                "status": "error",
                "agent_name": agent_name,
                "message": f"Agent '{agent_name}' not found in agent database"
            })
        
        # Step 2: Get the ARN ID and normalize it
        arn_id = agent.get('arn_id')
        normalized_arn_id = normalize_arn_id(arn_id)
        collection_name = f"{LOGS_COLLECTION_PREFIX}{normalized_arn_id}"
        
        # Step 3: Get the logs collection for this ARN ID
        client = get_mongo_client()
        logs_db = client[LOGS_DATABASE_NAME]
        user_collection = logs_db[collection_name]
        
        # Step 4: Aggregate token usage data
        usage_stats = aggregate_token_usage(user_collection)
        
        # Step 5: Return the results
        return json.dumps({
            "status": "success",
            "agent_name": agent_name,
            "arn_id": arn_id,
            "normalized_arn_id": normalized_arn_id,
            **usage_stats
        })
        
    except Exception as e:
        return handle_tool_error("get_agent_token_usage_by_name", e, agent_name=agent_name)

@tool
def get_agent_model_usage_summary(agent_name: str):
    """Get comprehensive model usage summary for an agent including actual model IDs from logs"""
    try:
        # Step 1: Find the agent by name
        agent = find_agent_by_name(agent_name)
        
        if not agent:
            return json.dumps({
                "status": "error",
                "agent_name": agent_name,
                "message": f"Agent '{agent_name}' not found in agent database"
            })
        
        # Step 2: Get the ARN ID and normalize it
        arn_id = agent.get('arn_id')
        normalized_arn_id = normalize_arn_id(arn_id)
        collection_name = f"{LOGS_COLLECTION_PREFIX}{normalized_arn_id}"
        
        # Step 3: Connect to MongoDB
        client = get_mongo_client()
        logs_db = client[LOGS_DATABASE_NAME]
        user_collection = logs_db[collection_name]
        
        # Step 4: Aggregate token usage data
        usage_stats = aggregate_token_usage(user_collection)
        
        # Step 5: Extract model IDs from logs
        model_ids = extract_model_ids_from_logs(user_collection)
        
        # Step 6: Return the comprehensive summary
        return json.dumps({
            "status": "success",
            "agent_name": agent_name,
            "arn_id": arn_id,
            "token_usage": {
                "total_events": usage_stats["total_events"],
                "total_input_tokens": usage_stats["total_input_tokens"],
                "total_output_tokens": usage_stats["total_output_tokens"],
                "total_tokens": usage_stats["total_tokens"],
                "first_event": usage_stats["first_event"],
                "last_event": usage_stats["last_event"]
            },
            "model_usage": {
                "actual_model_ids_from_logs": model_ids,
                "total_unique_models": len(model_ids)
            }
        })
        
    except Exception as e:
        return handle_tool_error("get_agent_model_usage_summary", e, agent_name=agent_name)

@tool
def sync_bedrock_logs():
    """Sync Bedrock model invocation logs from CloudWatch to MongoDB"""
    try:
        # Use credentials from the module-level credentials manager
        manager = BedrockLogsManager(
            aws_access_key_id=credentials.aws_access_key_id,
            aws_secret_access_key=credentials.aws_secret_access_key,
            region_name=credentials.region_name
        )
        manager.sync_bedrock_logs()
        return json.dumps({
            "status": "success",
            "message": "Bedrock logs sync completed successfully"
        })
    except Exception as e:
        return handle_tool_error("sync_bedrock_logs", e)

@tool
def get_token_usage_by_arn_id(arn_id: str) -> str:
    """Get token usage statistics for a specific ARN ID"""
    try:
        # Step 1: Normalize the ARN ID
        normalized_arn_id = normalize_arn_id(arn_id)
        collection_name = f"{LOGS_COLLECTION_PREFIX}{normalized_arn_id}"
        
        # Step 2: Get the logs collection
        client = get_mongo_client()
        logs_db = client[LOGS_DATABASE_NAME]
        user_collection = logs_db[collection_name]
        
        # Step 3: Aggregate token usage data
        usage_stats = aggregate_token_usage(user_collection)
        
        # Step 4: Return results
        return json.dumps({
            "status": "success",
            "arn_id": arn_id,
            "normalized_arn_id": normalized_arn_id,
            **usage_stats
        })
        
    except Exception as e:
        return handle_tool_error("get_token_usage_by_arn_id", e, arn_id=arn_id)

@tool
def get_bedrock_model_metrics(model_id: str):
    """Get model-specific metrics from CloudWatch for a given Bedrock model ID"""
    try:
        # Use credentials from the module-level credentials manager
        if credentials.aws_access_key_id and credentials.aws_secret_access_key:
            cloudwatch = boto3.client(
                'cloudwatch', 
                region_name=credentials.region_name,
                aws_access_key_id=credentials.aws_access_key_id,
                aws_secret_access_key=credentials.aws_secret_access_key
            )
        else:
            cloudwatch = boto3.client('cloudwatch', region_name=REGION)

        # Calculate time range (last 24 hours)
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(hours=24)
        
        # Define metrics to retrieve
        metrics_config = [
            ('Invocations', 'Sum'),
            ('InvocationLatency', 'Average'),
            ('InputTokenCount', 'Sum'),
            ('OutputTokenCount', 'Sum')
        ]
        
        queries = []
        for metric_name, stat in metrics_config:
            queries.append({
                'Id': f"{metric_name.lower()}_{stat.lower()}",
                'Label': f"{metric_name} ({stat})",
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Bedrock',
                        'MetricName': metric_name,
                        'Dimensions': [
                            {
                                'Name': 'ModelId',
                                'Value': model_id
                            }
                        ]
                    },
                    'Period': 300,
                    'Stat': stat,
                },
                'ReturnData': True,
            })

        response = cloudwatch.get_metric_data(
            MetricDataQueries=queries,
            StartTime=start_time,
            EndTime=end_time,
            ScanBy='TimestampDescending'
        )

        metrics = []
        for result in response['MetricDataResults']:
            metrics.append({
                "metric": result['Label'],
                "timestamps": [ts.isoformat() for ts in result['Timestamps']],
                "values": result['Values']
            })

        return json.dumps({
            "status": "success",
            "model_id": model_id,
            "metrics": metrics
        })

    except Exception as e:
        return handle_tool_error("get_bedrock_model_metrics", e, model_id=model_id)

@tool
def debug_mongodb_connection():
    """Debug MongoDB connection issues"""
    try:
        client = get_mongo_client()
        
        # List all databases
        databases = client.list_database_names()
        print(f"Available databases: {databases}")
        
        # Check agent_db
        agent_db_results = {}
        if AGENT_DATABASE_NAME in databases:
            agent_db = client[AGENT_DATABASE_NAME]
            agent_collections = agent_db.list_collection_names()
            agent_db_results = {
                "name": AGENT_DATABASE_NAME,
                "collections": agent_collections,
                "exists": True
            }
            
            if AGENT_COLLECTION in agent_collections:
                agent_collection = agent_db[AGENT_COLLECTION]
                count = agent_collection.count_documents({})
                agent_db_results["agent_collection_stats"] = {
                    "name": AGENT_COLLECTION,
                    "document_count": count
                }
                
                # Get a sample agent
                sample_agent = agent_collection.find_one()
                if sample_agent:
                    agent_db_results["sample_agent"] = {
                        "name": sample_agent.get("name"),
                        "agent_id": sample_agent.get("agent_id"),
                        "arn_id": sample_agent.get("arn_id")
                    }
        else:
            agent_db_results = {
                "name": AGENT_DATABASE_NAME,
                "exists": False
            }
            
        # Check logs_db
        logs_db_results = {}
        if LOGS_DATABASE_NAME in databases:
            logs_db = client[LOGS_DATABASE_NAME]
            logs_collections = logs_db.list_collection_names()
            log_collections = [c for c in logs_collections if c.startswith(LOGS_COLLECTION_PREFIX)]
            
            logs_db_results = {
                "name": LOGS_DATABASE_NAME,
                "exists": True,
                "collections": log_collections,
                "count": len(log_collections)
            }
        else:
            logs_db_results = {
                "name": LOGS_DATABASE_NAME,
                "exists": False
            }
            
        return json.dumps({
            "status": "success",
            "connection_successful": True,
            "databases": databases,
            "agent_database": agent_db_results,
            "logs_database": logs_db_results
        })
    except Exception as e:
        return handle_tool_error("debug_mongodb_connection", e)

class LoggingMetricAgent(BaseAgent):
    """Logging Metric agent to perform Bedrock log sync and token usage analysis by ARN ID only"""

    def __init__(self, aws_access_key_id=None, aws_secret_access_key=None, region_name='us-east-1'):
        # Store credentials in the module-level credentials manager
        credentials.aws_access_key_id = aws_access_key_id
        credentials.aws_secret_access_key = aws_secret_access_key
        credentials.region_name = region_name or 'us-east-1'
        
        # Call parent constructor
        super().__init__(aws_access_key_id, aws_secret_access_key, region_name)

    def _requires_json_only(self) -> bool:
        """This agent requires JSON-only responses"""
        return True

    def _get_tools(self) -> List:
        """Return logging metric tools"""
        return [
            sync_bedrock_logs,
            get_token_usage_by_arn_id,
            get_bedrock_model_metrics,
            get_agent_arn_id_by_name,
            get_agent_token_usage_by_name,
            get_agent_model_usage_summary,
            debug_mongodb_connection
        ]

    def _get_system_message(self) -> str:
        """Return agent-specific system message"""
        return """You are a JSON-only Bedrock logging metric system. You must respond EXCLUSIVELY with the JSON output from tools - NO additional text.
Available tools:

sync_bedrock_logs(): Sync Bedrock model invocation logs from CloudWatch
get_token_usage_by_arn_id(arn_id): Get token usage statistics for a specific ARN ID
get_bedrock_model_metrics(model_id): Get model-specific metrics from CloudWatch for a given Bedrock model ID
get_agent_arn_id_by_name(agent_name): Get ARN ID for a specific agent name from the agent database
get_agent_token_usage_by_name(agent_name): Get token usage statistics for a specific agent by name
get_agent_model_usage_summary(agent_name): Get comprehensive model usage summary for an agent
debug_mongodb_connection(): Debug MongoDB connection issues

CRITICAL:
- Use tools to get JSON responses
- Return ONLY the tool's JSON output
- NO explanations or summaries
- Only call sync_bedrock_logs() when getting token usage or other log-based statistics
- DO NOT call sync_bedrock_logs() when retrieving model metrics, agent ARN IDs, or debugging connections
- Only supports querying by ARN ID (e.g., 'sushmita-sahu', 'agentops-iam-user') or agent name
- Return tool JSON output directly."""

    def get_agent_description(self) -> str:
        """Return description of logging metric capabilities"""
        return "Bedrock Logging Metric operations with JSON-only responses (sync Bedrock logs, token usage analysis by arn_id or agent name, get model-specific metrics from CloudWatch, agent ARN ID lookup)"