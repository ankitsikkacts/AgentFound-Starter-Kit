"""
Main Multi-Agent System implementation.
Imports and coordinates all agents.
"""

import logging
from typing import Dict
from BaseAgent import BaseCoordinator, BaseAgent
from MathAgent import MathAgent
from TextAgent import TextAgent
from TodoAgent import TodoAgent
from RegistrationAgent import RegistrationAgent
from config import get_aws_credentials

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load AWS credentials from config_agent.json
aws_creds = get_aws_credentials("config_agent")

class CoordinatorAgent(BaseCoordinator):
    """Coordinator agent that manages different specialized agents"""
    
    def _initialize_agents(self) -> Dict[str, BaseAgent]:
        """Initialize all available agents"""
        return {
            "math": MathAgent(self.aws_access_key_id, self.aws_secret_access_key, self.region_name),
        }

class MultiAgentSystem:
    """Main multiagent system using LangGraph"""
    
    def __init__(self, aws_access_key_id: str, aws_secret_access_key: str, region_name: str = 'us-east-1'):
        self.coordinator = CoordinatorAgent(aws_access_key_id, aws_secret_access_key, region_name)
        logger.info("MultiAgent system initialized with LangGraph")
    
    def process_request(self, user_input: str, thread_id: str = "default") -> str:
        """Process a user request"""
        return self.coordinator.process_request(user_input, thread_id)
    
    def list_agents(self) -> Dict[str, str]:
        """List all available agents"""
        return self.coordinator.list_agents()
    
    def get_conversation_history(self, agent_type: str = "math", thread_id: str = "default") -> list:
        """Get conversation history"""
        return self.coordinator.get_agent_conversation_history(agent_type, thread_id)
    
def main():
    """Example usage of the LangGraph multiagent system"""
    try:
        # Initialize the multiagent system with credentials from config_agent.json
        math_agent = MultiAgentSystem(
            aws_access_key_id=aws_creds["aws_access_key_id"],
            aws_secret_access_key=aws_creds["aws_secret_access_key"],
            region_name=aws_creds["region_name"]
        )
        
        # Example interactions
        print("\n" + "="*40)
        print("Example interactions:")
        print("="*40)

        response1 = math_agent.process_request("Add 2+3", "demo_thread")
        print(f"Agent: {response1}")

        response2 = math_agent.process_request("multiply by 2", "demo_thread")
        print(f"Agent: {response2}")

    except Exception as e:
        logger.error(f"Error: {e}")
        print(f"Error: {e}")
        print("Please make sure you have valid AWS credentials and Bedrock access.")

if __name__ == "__main__":
    main()