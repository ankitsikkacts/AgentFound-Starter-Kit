import streamlit as st
import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import boto3
from datetime import datetime, timedelta
from typing import List, Dict, Optional

# Set page title and layout
st.set_page_config(page_title="Agent Ops Dashboard", layout="wide")

BASE_URL = "http://127.0.0.1:8085/call_agentOps_agent"
HEADERS = {"Content-Type": "application/json"}

# Custom CSS
st.markdown("""
    <style>
        .stApp {
            background: linear-gradient(to right, #000080, #ff7f50);
            background-attachment: fixed;
        }

        /* Target the Fetch Logs button with its specific attributes */
button[kind="secondary"][data-testid="stBaseButton-secondary"] {
    background-color: #ff0000 !important;
    color: white !important;
    border: none !important;
}

/* Target the text container inside the button */
button[kind="secondary"][data-testid="stBaseButton-secondary"] .st-emotion-cache-rxbcmk p {
    color: white !important;
}

/* Fix hover state */
button[kind="secondary"][data-testid="stBaseButton-secondary"]:hover {
    background-color: #cc0000 !important;
    color: white !important;
}

/* Target the specific emotion-cache class */
.st-emotion-cache-1rwb540 {
    background-color: #ff0000 !important;
    color: white !important;
}

/* Ensure the download button also gets styled */
div.stDownloadButton button {
    background-color: #ff0000 !important;
    color: white !important;
}
        /* More specific selectors for the buttons */
        button[kind="secondary"], 
        div.stDownloadButton button,
        button[data-testid="StyledFullScreenButton"] {
            background-color: #ff0000 !important;
            color: white !important;
            border-color: transparent !important;
        }

        /* Fix hover states */
        button[kind="secondary"]:hover, 
        div.stDownloadButton button:hover,
        button[data-testid="StyledFullScreenButton"]:hover {
            background-color: #cc0000 !important;
            color: white !important;
        }

        /* Target buttons by their contained text */
        button:has(div:contains("Fetch Logs")), 
        button:has(div:contains("Download Full Logs")) {
            background-color: #ff0000 !important;
            color: white !important;
        }

        /* Additional styling for the fullscreen button */
        [data-testid="StyledFullScreenButton"] {
            background-color: #ff0000 !important;
            fill: white !important;
        }

        /* Override any Streamlit defaults with !important flags */
        .stButton button {
            background-color: #ff0000 !important;
            color: white !important;
        }
        .white-text {
            color: white !important;
        }

        .metric-box {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            text-align: center;
            margin-bottom: 20px;
        }

        .metric-label, .metric-value {
            color: white !important;
        }
        
        .logs-container {
            background-color: rgba(0, 0, 0, 0.2);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        
        .tab-header {
            color: white !important;
            font-size: 1.5em;
            margin-bottom: 15px;
        } 
        
        .alert-header {
            font-size: 16px !important;
            color: white;
        }
        
        div[data-testid="stDataFrame"] div {
            font-size: 10px !important;
        }
        
        /* Make all slider text white */
        div[data-testid="stSlider"] label {
            color: white !important;
        }
        
        /* Make number inputs white text */
        div[data-testid="stNumberInput"] label {
            color: white !important;
        }
        
        /* Make radio buttons white */
        div[data-testid="stRadio"] label {
            color: white !important;
        }
        
        /* Make checkboxes white */
        div[data-testid="stCheckbox"] label {
            color: white !important;
        }
        
        /* Make selectbox text white */
        div[data-testid="stSelectbox"] label {
            color: white !important;
        }
        
        /* All input labels white */
        .stTextInput > label, .stTextArea > label {
            color: white !important;
        }
        
        /* Info, success, error box text */
        div[data-testid="stInfo"], div[data-testid="stSuccess"], div[data-testid="stWarning"] {
            color: white !important;
        }
        
        /* Metric text in white */
        [data-testid="stMetricValue"] {
            color: white !important;
        }
        
        [data-testid="stMetricLabel"] {
            color: white !important;
        }
        
        /* Expander text in white */
        [data-testid="stExpander"] {
            color: white !important;
        }
        
        /* All buttons text */
        button {
            color: white !important;
        }
        
        .stTabs [data-baseweb="tab-list"] {
            gap: 24px;
        }
        
        .stTabs [data-baseweb="tab"] {
            background-color: rgba(255,255,255,0.1);
            padding: 10px 20px;
            border-radius: 4px;
            color: white;
        }
        
        .stTabs [aria-selected="true"] {
            background-color: rgba(255,255,255,0.2);
            border-bottom: 2px solid white;
        }
    </style>
""", unsafe_allow_html=True)

# Utility functions for AWS config
def read_aws_config(config_name="config_server"):
    """Read AWS credentials from JSON config file"""
    try:
        import os
        # Determine the config file path
        config_file = f"{config_name}.json"
        current_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(current_dir, config_file)
        
        # Check if file exists
        if not os.path.exists(config_path):
            st.error(f"Config file not found: {config_file}")
            return None
        
        # Read and parse the JSON config
        with open(config_path, 'r') as f:
            config_data = json.load(f)
            
        return config_data
        
    except Exception as e:
        st.error(f"Error reading config file {config_name}: {str(e)}")
        return None

# Fetch agent counts and metadata
def fetch_counts_and_metadata():
    try:
        data_active = {"query": "provide the count of active agents"}
        response_active = requests.post(BASE_URL, headers=HEADERS, json=data_active)
        active_agents = response_active.json().get("total_active_agents", "N/A")
        agents = response_active.json().get("active_agents", [])

        agent_names = sorted([agent["name"] for agent in agents])
        agent_metadata = {agent["name"]: agent for agent in agents}

        data_all = {"query": "provide the count of registered agents"}
        response_all = requests.post(BASE_URL, headers=HEADERS, json=data_all)
        all_agents = response_all.json().get("total_agents", "N/A")

        return all_agents, active_agents, agent_names, agent_metadata
    except Exception as e:
        st.error(f"Error fetching agent data: {e}")
        return "Error", "Error", [], {}

# Fetch token usage for a selected agent
def fetch_agent_metrics(agent_name):
    try:
        data = {"query": f"get the latest token usage for the agent {agent_name}"}
        response = requests.post(BASE_URL, headers=HEADERS, json=data)
        return response.json().get("results", [{}])[0]
    except Exception as e:
        st.error(f"Error fetching metrics for {agent_name}: {e}")
        return {}

# Fetch model metrics for a selected agent
def fetch_model_metrics(agent_name):
    try:
        data = {"query": f"share the model metric of the agent {agent_name}"}
        response = requests.post(BASE_URL, headers=HEADERS, json=data)
        return response.json().get("results", [{}])[0]
    except Exception as e:
        st.error(f"Error fetching model metrics for {agent_name}: {e}")
        return {}

# Bedrock logs retrieval function
def get_model_invocation_logs(
    log_group_name: str,
    agent_id: str,
    region_name: str = 'us-east-1',
    hours_back: int = 24,
    aws_access_key_id=None,
    aws_secret_access_key=None,
    max_logs=100
) -> List[Dict]:
    """
    Read model invocation logs from CloudWatch and filter by agent ID.
    
    Args:
        log_group_name: CloudWatch log group name
        agent_id: Agent ID or username part of ARN
        region_name: AWS region name
        hours_back: How many hours back to search for logs
    
    Returns:
        List of the filtered log events
    """
    
    # Initialize CloudWatch Logs client
    cloudwatch_client = boto3.client(
        'logs', 
        region_name=region_name,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key
    )
    
    # Calculate time range (CloudWatch expects timestamps in milliseconds)
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(hours=hours_back)
    start_timestamp = int(start_time.timestamp() * 1000)
    end_timestamp = int(end_time.timestamp() * 1000)
    
    # Remove full ARN if provided, extract just the username part
    if 'arn:aws:iam::' in agent_id and '/user/' in agent_id:
        agent_id = agent_id.split('/user/')[-1]
        st.markdown('<div class="white-text">Extracted username from ARN: {}</div>'.format(agent_id), unsafe_allow_html=True)
    
    filtered_logs = []
    next_token = None
    
    try:
        # Loop to handle pagination of results
        while True:
            kwargs = {
                'logGroupName': log_group_name,
                'startTime': start_timestamp,
                'endTime': end_timestamp,
                'limit': 1000  # Maximum allowed by API
            }
            
            if next_token:
                kwargs['nextToken'] = next_token
                
            # Get logs from CloudWatch
            response = cloudwatch_client.filter_log_events(**kwargs)
            
            # Process this batch of logs
            for event in response.get('events', []):
                try:
                    # Parse the log message as JSON
                    log_data = json.loads(event['message'])
                    
                    # Check if the log is for our agent
                    identity_arn = log_data.get('identity', {}).get('arn', '')
                    
                    # Filter by agent ID - it should appear in the ARN
                    if agent_id in identity_arn:
                        # Add timestamp for reference
                        log_data['cloudwatch_timestamp'] = datetime.fromtimestamp(
                            event['timestamp'] / 1000
                        ).isoformat()
                        
                        filtered_logs.append(log_data)
                        
                        # Break if we have enough logs
                        if len(filtered_logs) >= max_logs:
                            break
                except json.JSONDecodeError:
                    continue  # Skip non-JSON messages
                except Exception as e:
                    continue  # Skip any errors in processing individual logs
            
            # Break if we have enough logs or there are no more pages
            if len(filtered_logs) >= max_logs or 'nextToken' not in response:
                break
                
            next_token = response['nextToken']
        
        # Sort by timestamp (most recent first)
        filtered_logs.sort(
            key=lambda x: x.get('timestamp', x.get('cloudwatch_timestamp', '')), 
            reverse=True
        )
        
        return filtered_logs[:max_logs]  # Limit to max_logs
        
    except Exception as e:
        st.markdown(f'<div class="white-text">Error querying CloudWatch logs: {str(e)}</div>', unsafe_allow_html=True)
        return []

def parse_logs_for_display(logs):
    """Extract relevant information from logs for display in a table"""
    parsed_data = []
    
    for log in logs:
        try:
            # Extract common fields
            timestamp = log.get('timestamp', log.get('cloudwatch_timestamp', 'Unknown'))
            if isinstance(timestamp, str) and timestamp.endswith('Z'):
                # Convert from ISO format
                timestamp = timestamp.replace('Z', '+00:00')
                try:
                    dt = datetime.fromisoformat(timestamp)
                    timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    pass
                
            request_id = log.get('requestId', 'Unknown')
            model_id = log.get('modelId', 'Unknown')
            
            # Extract token counts
            input_tokens = 0
            output_tokens = 0
            
            # Try to get from output.outputBodyJson.usage first
            if 'output' in log and 'outputBodyJson' in log['output']:
                output_body = log['output']['outputBodyJson']
                if isinstance(output_body, str):
                    try:
                        output_body = json.loads(output_body)
                    except:
                        pass
                
                if isinstance(output_body, dict) and 'usage' in output_body:
                    input_tokens = output_body['usage'].get('input_tokens', 0)
                    output_tokens = output_body['usage'].get('output_tokens', 0)
            
            # If we couldn't find token counts above, try input/output fields
            if input_tokens == 0 and 'input' in log:
                input_tokens = log['input'].get('inputTokenCount', 0)
            
            if output_tokens == 0 and 'output' in log:
                output_tokens = log['output'].get('outputTokenCount', 0)
            
            # Extract input message - simplify to show only the last user message for display
            input_message = "No message found"
            if 'input' in log and 'inputBodyJson' in log['input']:
                input_body = log['input']['inputBodyJson']
                
                if isinstance(input_body, str):
                    try:
                        input_body = json.loads(input_body)
                    except:
                        input_message = input_body[:100] + "..." if len(input_body) > 100 else input_body
                        
                if isinstance(input_body, dict) and 'messages' in input_body:
                    messages = input_body.get('messages', [])
                    if messages:
                        # Get the last user message
                        for msg in reversed(messages):
                            if isinstance(msg, dict) and msg.get('role') == 'user':
                                content = msg.get('content', '')
                                if isinstance(content, list):  # Handle array content
                                    text_content = []
                                    for item in content:
                                        if isinstance(item, dict) and 'text' in item:
                                            text_content.append(item['text'])
                                    if text_content:
                                        content = ' '.join(text_content)
                                if content:
                                    input_message = content[:100] + "..." if len(content) > 100 else content
                                    break
            
            # Extract output message
            output_message = "No response found"
            if 'output' in log and 'outputBodyJson' in log['output']:
                output_body = log['output']['outputBodyJson']
                
                if isinstance(output_body, str):
                    try:
                        output_body = json.loads(output_body)
                    except:
                        output_message = output_body[:100] + "..." if len(output_body) > 100 else output_body
                
                if isinstance(output_body, dict):
                    if 'content' in output_body:
                        content = output_body['content']
                        if isinstance(content, list):
                            text_parts = []
                            for part in content:
                                if isinstance(part, dict):
                                    if part.get('type') == 'text':
                                        text_parts.append(part.get('text', ''))
                                    elif part.get('type') == 'tool_use':
                                        text_parts.append(f"Tool: {part.get('name', '')}")
                            if text_parts:
                                output_message = ' '.join(text_parts)[:100] + "..." if len(' '.join(text_parts)) > 100 else ' '.join(text_parts)
                        else:
                            output_message = str(content)[:100] + "..." if len(str(content)) > 100 else str(content)
            
            # Add to results - ensure all fields are strings to avoid PyArrow conversion issues
            parsed_data.append({
                'Timestamp': str(timestamp),
                'Request ID': str(request_id),
                'Model ID': str(model_id),
                'Input Tokens': int(input_tokens),
                'Output Tokens': int(output_tokens),
                'Total Tokens': int(input_tokens + output_tokens),
                'Input Message': str(input_message),
                'Output Message': str(output_message)
            })
            
        except Exception as e:
            st.markdown(f'<div class="white-text">Error parsing log entry: {str(e)}</div>', unsafe_allow_html=True)
    
    return parsed_data

# Main app
try:
    # Check if header.png exists, load it if it does
    import os
    if os.path.exists("header.png"):
        st.image("header.png", use_container_width=True)
except:
    pass  # Just continue if header image doesn't exist

# Dashboard tabs
tab1, tab2 = st.tabs(["Agent Dashboard", "Bedrock Invocation Logs"])

with tab1:
    # Dashboard Header
    st.markdown('<div class="white-text"><h2> <b>AI Agent Factory</b></h2></div>', unsafe_allow_html=True)
    st.markdown('<div class="white-text"><p><b>Welcome!</b> This dashboard provides real-time insights into your registered and active agents.</p></div>', unsafe_allow_html=True)
    
    # Fetch and store agent data
    if "agent_data" not in st.session_state:
        st.session_state.agent_data = fetch_counts_and_metadata()
    
    all_agents, active_agents, agent_names, agent_metadata = st.session_state.agent_data
    # Agent Counts
    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"""
            <div class="metric-box">
                <div class="metric-label"><b>Registered Agents</b></div>
                <div class="metric-value">{all_agents}</div>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
            <div class="metric-box">
                <div class="metric-label"><b>Active Agents</b></div>
                <div class="metric-value">{active_agents}</div>
            </div>
        """, unsafe_allow_html=True)
    
    # Agent selection
    st.markdown("<br><br>", unsafe_allow_html=True)
    
    st.markdown('<div class="white-text"><h3> <b>Agent Metrics</b></h3></div>', unsafe_allow_html=True)
    selected_agent = st.selectbox("", agent_names, key="agent_select")
    
    # Store selected agent in session state for use in other tabs
    if selected_agent and selected_agent != st.session_state.get('selected_agent'):
        st.session_state['selected_agent'] = selected_agent
        # Get ARN ID for the selected agent - save for Bedrock logs tab
        if agent_metadata and selected_agent in agent_metadata:
            st.session_state['agent_arn_id'] = agent_metadata[selected_agent].get('arn_id')
    
    # Display selected agent description and metrics
    if selected_agent:
        agent_info = agent_metadata.get(selected_agent, {})
    
        metrics = fetch_agent_metrics(selected_agent)
        input_tokens = metrics.get("total_input_tokens", 0)
        output_tokens = metrics.get("total_output_tokens", 0)
        total_requests = metrics.get("total_events", 0)
        total_cost = (input_tokens / 1_000_000) * 3 + (output_tokens / 1_000_000) * 15
    
        st.markdown(f"""
          <div class="metric-box">
              <div class="metric-value"><b>{selected_agent}</b></div>
              <div class="metric-value" style="font-size:18px;">{agent_info.get("desc", "No description available")}</div>
          </div>
      """, unsafe_allow_html=True)
    
        col1, col2 = st.columns(2)
    
        with col1:
            st.markdown(f"""
                <div class="metric-box">
                    <div class="metric-label"><b>Total Requests</b></div>
                    <div class="metric-value">{total_requests}</div>
                </div>
                <div class="metric-box">
                    <div class="metric-label"><b>Input Tokens</b></div>
                    <div class="metric-value">{input_tokens}</div>
                </div>
            """, unsafe_allow_html=True)
    
        with col2:
            st.markdown(f"""
                <div class="metric-box">
                    <div class="metric-label"><b>Total Cost</b></div>
                    <div class="metric-value">\\${total_cost:.4f}</div>
                </div>
                <div class="metric-box">
                    <div class="metric-label"><b>Output Tokens</b></div>
                    <div class="metric-value">{output_tokens}</div>
                </div>
            """, unsafe_allow_html=True)
    
        st.markdown("<br><br>", unsafe_allow_html=True)
    
        st.markdown(f'<div class="white-text"><h4> <b>Agent Performance - {selected_agent}</b></h4></div>', unsafe_allow_html=True)
        model_metrics = fetch_model_metrics(selected_agent)
    
        if model_metrics.get("status") == "success":
            metric_map = {
                "InvocationLatency": "Invocation Latency (ms)",
                "ModelInvocationClientErrors": "Client Errors",
                "ModelInvocationServerErrors": "Server Errors"
            }
    
            col1, col2, col3 = st.columns(3)
            for metric in model_metrics.get("metrics", []):
                if metric["metric"] in metric_map:
                    label = metric_map[metric["metric"]]
                    latest_value = metric["values"][0] if metric["values"] else "N/A"
    
                    with col1 if metric["metric"] == "InvocationLatency" else \
                         col2 if metric["metric"] == "ModelInvocationClientErrors" else col3:
                        st.markdown(f"""
                            <div class="metric-box">
                                <div class="metric-label"><b>{label}</b></div>
                                <div class="metric-value">{latest_value}</div>
                            </div>
                        """, unsafe_allow_html=True)
        else:
            st.markdown('<div class="white-text">Failed to fetch model metrics</div>', unsafe_allow_html=True)
    
        # Dummy data for AWS Bedrock cost over the last 10 days
        cost_dates = pd.date_range(end=pd.Timestamp.today(), periods=10)
        cost_values = [3.06, 8.9, 12.3, 12.5, 23, 25.25, 30.96, 33.45, 35, 37]
        df_cost = pd.DataFrame({"Date": cost_dates, "Cost (USD)": cost_values})
        df_cost["Date"] = df_cost["Date"].dt.strftime('%b %d')  # Shorten date format
    
        # Dummy data for latency over the last 3 days
        latency_dates = pd.date_range(end=pd.Timestamp.today(), periods=3)
        latency_values = [1800 , 548, 846]
        df_latency = pd.DataFrame({"Date": latency_dates, "Latency (ms)": latency_values})
        df_latency["Date"] = df_latency["Date"].dt.strftime('%b %d')  # Shorten date format
    
        # Set seaborn theme
        sns.set_theme(style="whitegrid")
    
        # Create side-by-side plots
        col1, col2 = st.columns(2)
    
        with col1:
            st.markdown('<div class="white-text"><h4><b>Budget vs Spend</b></h4></div>', unsafe_allow_html=True)
            fig1, ax1 = plt.subplots(figsize=(6, 4))
            sns.lineplot(data=df_cost, x="Date", y="Cost (USD)", marker="o", ax=ax1, color="blue")
            ax1.axhline(y=35, color='red', linestyle='--', label='Threshold')
            ax1.set_title("Cost Over Time", fontsize=14)
            ax1.set_xlabel("Date")
            ax1.set_ylabel("Cost (USD)")
            ax1.legend()
            plt.xticks(rotation=45)
            st.pyplot(fig1)
    
        with col2:
            st.markdown('<div class="white-text"><h4><b>Agent Response</b></h4></div>', unsafe_allow_html=True)
            fig2, ax2 = plt.subplots(figsize=(6, 4))
            sns.lineplot(data=df_latency, x="Date", y="Latency (ms)", marker="o", ax=ax2, color="orange")
            ax2.set_title("Latency Over Time", fontsize=14)
            ax2.set_xlabel("Date")
            ax2.set_ylabel("Latency (ms)")
            plt.xticks(rotation=45)
            st.pyplot(fig2)
    
        # Critical Alerts
        critical_alerts = [
            ["07-02 15:45","Agent Monitor", "Failure rate at 35% in the last 10 mins. Check upstream service errors or degradation."],
            ["07-02 10:06","TextAgent", "Accuracy dropped to 72% (Threshold: 85%). Possible drift or misalignment."],
            ["07-01 23:36","MathAgent", "Exceeded max response time. Latency:12.4s (Threshold: 8s). Investigate Immediately."],
            ["07-01 18:39","TextAgent", "Showing low confidence scores on 40% of queries. Consider review or retraining."],
            ["07-01 15:06","Agent Monitor", "CPU usage at 95% (avg: 65%) for last 5 mins. Scaling may be needed."]
        ]
        df_critical = pd.DataFrame(critical_alerts, columns=["Timestamp","Agent Name", "Alert Message"])
    
        # Warning Alerts
        warning_alerts = [
            ["07-02 12:15","Agent Monitor", "Response latency trending upward. Current: 6.2s | Baseline: 3.5s"],
            ["07-02 11:46","Agent Monitor", "Retry count increased by 60% in the last hour. Backend stability suspected."],
            ["07-02 08:30","TextAgent", "CSAT dropped to 3.2/5.0. Check recent interaction samples."],
            ["07-02 00:45","MathAgent", "Memory usage increased by 40% over 10 mins. Potential memory leak."]
        ]
        df_warning = pd.DataFrame(warning_alerts, columns=["Timestamp","Agent Name", "Alert Message"])
    
        # Display tables
        st.markdown("<br>", unsafe_allow_html=True)
    
        st.markdown('<div class="alert-header"><b> Critical Alerts</b></div>', unsafe_allow_html=True)
        st.dataframe(df_critical,hide_index=True)
        st.markdown("<br>", unsafe_allow_html=True)
    
        st.markdown('<div class="alert-header"><b> Warning Level Alerts</b></div>', unsafe_allow_html=True)
        st.dataframe(df_warning, hide_index=True)

with tab2:
    st.markdown('<div class="white-text"><h2> <b>Bedrock Model Invocation Logs</b></h2></div>', unsafe_allow_html=True)
    
    # Container for Bedrock logs configuration
    with st.container():
        st.markdown('<div class="white-text"><h4> <b>Log Configuration</b></h4></div>', unsafe_allow_html=True)
        
        # Use selected agent from first tab if available
        default_agent_id = ""
        if "selected_agent" in st.session_state:
            selected_agent_name = st.session_state["selected_agent"]
            if "agent_arn_id" in st.session_state:
                default_agent_id = st.session_state["agent_arn_id"]
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # Get config from file
            use_config_file = st.checkbox('Use config_server.json', value=True, key="use_config_checkbox")
            
            if use_config_file:
                config = read_aws_config()
                if config:
                    aws_access_key_id = config.get('aws_access_key_id')
                    aws_secret_access_key = config.get('aws_secret_access_key')
                    region_name = config.get('region_name', 'us-east-1')
                    
                    # Show masked key ID
                    if aws_access_key_id:
                        masked_key = aws_access_key_id[:4] + '*****' + aws_access_key_id[-4:] if len(aws_access_key_id) > 8 else "****"
                        st.markdown(f'<div class="white-text">Using credentials (Key ID: {masked_key})</div>', unsafe_allow_html=True)
                else:
                    st.markdown('<div class="white-text">Failed to load config. Please enter credentials manually.</div>', unsafe_allow_html=True)
                    use_config_file = False
            
            if not use_config_file:
                aws_access_key_id = st.text_input('AWS Access Key ID', key="aws_key_input")
                aws_secret_access_key = st.text_input('AWS Secret Access Key', type='password', key="aws_secret_input")
                region_name = st.text_input('AWS Region', value='us-east-1', key="aws_region_input")
        
        with col2:
            # Time range and log count
            log_group_name = st.text_input('CloudWatch Log Group', value='/aws/bedrock/model-invocations', key="log_group_input")
            hours_back = st.slider('Hours back', min_value=1, max_value=72, value=24, key="hours_slider", on_change=None)
            max_logs = st.slider('Max logs', min_value=5, max_value=100, value=20, key="max_logs_slider", on_change=None)
        
        with col3:
            # Agent selection - if no selection from tab1, show manual input
            if not default_agent_id:
                agent_id = st.text_input('Agent ID (e.g., agentops-iam-user)', key="agent_id_input")
                st.markdown('<div class="white-text">Enter the agent\'s ARN ID or just the username part</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="white-text">Using agent: {selected_agent_name}</div>', unsafe_allow_html=True)
                st.markdown(f'<div class="white-text">ARN ID: {default_agent_id}</div>', unsafe_allow_html=True)
                agent_id = default_agent_id
            
            # Add fetch button
            fetch_logs = st.button('Fetch Logs', key="fetch_logs_btn")
    
    # Process fetch logs request
    if fetch_logs:
        if not agent_id:
            st.markdown('<div class="white-text">Please enter an Agent ID or select an agent from the Dashboard tab</div>', unsafe_allow_html=True)
        elif not aws_access_key_id or not aws_secret_access_key:
            st.markdown('<div class="white-text">AWS credentials are required</div>', unsafe_allow_html=True)
        else:
            # Show loading message
            with st.spinner('Fetching logs from CloudWatch...'):
                # Fetch logs
                logs = get_model_invocation_logs(
                    log_group_name=log_group_name,
                    agent_id=agent_id,
                    region_name=region_name,
                    hours_back=hours_back,
                    aws_access_key_id=aws_access_key_id,
                    aws_secret_access_key=aws_secret_access_key,
                    max_logs=max_logs
                )
                
                if logs:
                    # Parse logs for display
                    parsed_logs = parse_logs_for_display(logs)
                    
                    # Store in session state for display
                    st.session_state['bedrock_logs'] = logs
                    st.session_state['parsed_bedrock_logs'] = parsed_logs
                    
                    st.markdown(f'<div class="white-text">Successfully retrieved {len(logs)} logs</div>', unsafe_allow_html=True)
                else:
                    # Store empty results
                    st.session_state['bedrock_logs'] = []
                    st.session_state['parsed_bedrock_logs'] = []
                    st.markdown(f'<div class="white-text">No logs found for agent \'{agent_id}\'</div>', unsafe_allow_html=True)
    
    # Display logs in a table
    if 'parsed_bedrock_logs' in st.session_state:
        st.markdown('<div class="logs-container">', unsafe_allow_html=True)
        
        if st.session_state['parsed_bedrock_logs']:
            # Create DataFrame for table display
            df = pd.DataFrame(st.session_state['parsed_bedrock_logs'])
            
            # Display token usage metrics
            col1, col2, col3, col4 = st.columns(4)
            
            total_input_tokens = df['Input Tokens'].sum()
            total_output_tokens = df['Output Tokens'].sum()
            total_tokens = df['Total Tokens'].sum()
            avg_tokens_per_request = int(total_tokens / len(df)) if len(df) > 0 else 0
            
            # Use metric widget with white text added in CSS
            col1.metric("Total Requests", len(df))
            col2.metric("Total Input Tokens", f"{total_input_tokens:,}")
            col3.metric("Total Output Tokens", f"{total_output_tokens:,}")
            col4.metric("Avg. Tokens/Request", f"{avg_tokens_per_request:,}")
            
            # Display the table with selected columns for overview
            st.markdown('<div class="white-text"><h4><b>Log Events Summary</b></h4></div>', unsafe_allow_html=True)
            st.dataframe(df[['Timestamp', 'Request ID', 'Model ID', 'Input Tokens', 'Output Tokens', 'Total Tokens']], use_container_width=True)
            
            # Add expandable sections for viewing details - Fix the PyArrow error by converting to strings
            with st.expander("View Request Messages"):
                # Convert to strings and create a new dataframe to avoid PyArrow conversion issues
                request_messages_df = pd.DataFrame({
                    'Request ID': df['Request ID'].astype(str),
                    'Input Message': df['Input Message'].astype(str)
                })
                st.dataframe(request_messages_df, use_container_width=True)
            
            with st.expander("View Response Messages"):
                # Convert to strings and create a new dataframe to avoid PyArrow conversion issues
                response_messages_df = pd.DataFrame({
                    'Request ID': df['Request ID'].astype(str),
                    'Output Message': df['Output Message'].astype(str)
                })
                st.dataframe(response_messages_df, use_container_width=True)
            
            # Option to download full logs as JSON - prevent page reload
            dl_json = json.dumps(st.session_state['bedrock_logs'], indent=2, default=str)
            dl_filename = f"bedrock_logs_{agent_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            st.download_button(
                label="Download Full Logs (JSON)",
                data=dl_json,
                file_name=dl_filename,
                mime="application/json",
                key="download_logs_btn"
            )
                
        else:
            st.markdown('<div class="white-text">No logs found for the specified agent.</div>', unsafe_allow_html=True)
            
            st.markdown('<div class="white-text">Possible reasons:</div>', unsafe_allow_html=True)
            st.markdown("""
            <div class="white-text">
            1. The agent ID might be incorrect or the format is wrong<br>
            2. No Bedrock model invocations for this agent in the selected time range<br>
            3. CloudWatch logs might not be enabled for Bedrock
            </div>
            """, unsafe_allow_html=True)
            
        st.markdown('</div>', unsafe_allow_html=True)
    
    else:
        st.markdown('<div class="white-text">Please configure the agent ID and click "Fetch Logs" to view model invocation logs</div>', unsafe_allow_html=True)
