import pytest
from httpx import AsyncClient
from fastapi.testclient import TestClient
import json
import os
#from unittest.mock import patch, MagicMock
import uuid # Make sure this is imported

# Import your FastAPI app and the MultiAgentSystem
from fastapi_endpoint import app
from fastapi_endpoint import system

# Import agent classes for 'spec='
from RegistrationAgent import RegistrationAgent
from LoggingMetricAgent import LoggingMetricAgent

# --- Fixtures for AWS Credentials (for MultiAgentSystem initialization) ---
@pytest.fixture(scope="module", autouse=True)
def setup_aws_credentials():
    original_aws_access_key_id = os.environ.get("AWS_ACCESS_KEY_ID")
    original_aws_secret_access_key = os.environ.get("AWS_SECRET_ACCESS_KEY")
    os.environ["AWS_ACCESS_KEY_ID"] = "test_access_key"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "test_secret_key"
    os.environ["AWS_REGION"] = "us-east-1"
    yield
    if original_aws_access_key_id is not None:
        os.environ["AWS_ACCESS_KEY_ID"] = original_aws_access_key_id
    else:
        del os.environ["AWS_ACCESS_KEY_ID"]
    if original_aws_secret_access_key is not None:
        os.environ["AWS_SECRET_ACCESS_KEY"] = original_aws_secret_access_key
    else:
        del os.environ["AWS_SECRET_ACCESS_KEY"]
    if "AWS_REGION" in os.environ:
        del os.environ["AWS_REGION"]

# --- Test Client Fixture ---
@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c

# --- Mocking Agents/Coordinator methods on the global system instance ---
@pytest.fixture(autouse=True)
def mock_system_methods(mocker): # Renamed fixture for clarity: it mocks methods on the 'system' object
    """
    Mocks key methods on the globally defined 'system' instance (from fastapi_endpoint)
    to control its behavior during tests.
    """
    mocker.patch(
        'fastapi_endpoint.system.list_agents',
        return_value={
            "registration": "Mock Registration Agent",
            "logging_token_metric": "Mock Logging Metric Agent"
        }
    )
    mocker.patch(
        'fastapi_endpoint.system.process_request',
        return_value=json.dumps({"mock_response": "processed_by_autouse_fixture"}) # Distinct return value
    )
    yield


# --- Test Cases for /get_all_agents ---
def test_get_all_agents_status_code(client):
    response = client.get("/get_all_agents")
    assert response.status_code == 200

def test_get_all_agents_response_format(client):
    response = client.get("/get_all_agents")
    data = response.json()
    assert "agents" in data
    assert isinstance(data["agents"], list)
    assert ["registration", "Mock Registration Agent"] in data["agents"]
    assert ["logging_token_metric", "Mock Logging Metric Agent"] in data["agents"]

def test_get_all_agents_empty_agents(client, mocker):
    mocker.patch('fastapi_endpoint.system.list_agents', return_value={})
    response = client.get("/get_all_agents")
    assert response.status_code == 200
    assert response.json() == {"agents": []}

# --- Test Cases for /call_agentOps_agent ---
def test_call_agentops_agent_status_code_success(client):
    query_payload = {"query": "test query for agent"}
    response = client.post("/call_agentOps_agent", json=query_payload)
    assert response.status_code == 200

def test_call_agentops_agent_response_format_success(client):
    query_payload = {"query": "another test query"}
    response = client.post("/call_agentOps_agent", json=query_payload)
    data = response.json()
    # Expect the return value from the autouse fixture's patch
    assert data == {"mock_response": "processed_by_autouse_fixture"}

def test_call_agentops_agent_invalid_input(client):
    invalid_payload = {"some_other_field": "value"}
    response = client.post("/call_agentOps_agent", json=invalid_payload)
    assert response.status_code == 422

    invalid_payload_type = {"query": 123}
    response = client.post("/call_agentOps_agent", json=invalid_payload_type)
    assert response.status_code == 422

def test_call_agentops_agent_coordinator_integration(client, mocker):
    """
    Verify that the process_request method of the system is called with correct arguments.
    """
    # Patch the process_request method on the `system` instance
    # This patch will override the one from the autouse fixture for this test
    # Ensure this assignment happens FIRST
    mock_process_request = mocker.patch(
        'fastapi_endpoint.system.process_request', # Correct path to patch the method called by the endpoint
        return_value=json.dumps({"test_response": "verified_by_this_test"}) # Return a specific value for this test
    )

    query_text = "test query for coordinator"
    query_payload = {"query": query_text}
    response = client.post("/call_agentOps_agent", json=query_payload)

    # Now you can use mock_process_request because it's been assigned
    mock_process_request.assert_called_once()
    # Check that the first argument to process_request is the query text
    assert mock_process_request.call_args[0][0] == query_text
    # Check that the second argument (thread_id) is a UUID object
    assert isinstance(mock_process_request.call_args[0][1], uuid.UUID)
    # You can still check its string representation for length if needed
    assert len(str(mock_process_request.call_args[0][1])) == 36

    assert response.status_code == 200
    assert response.json() == {"test_response": "verified_by_this_test"}

# Place this test function within your existing test_fastapi_endpoint.py file

def test_registered_agent_count_not_null(client):
    """
    Verifies that the /get_all_agents endpoint returns a non-empty list of agents.
    This test ensures the "registered agent count" is not null (i.e., not zero).
    """
    # Make a GET request to the endpoint that provides all agents
    response = client.get("/get_all_agents")

    # Assert that the API call was successful
    assert response.status_code == 200, f"Expected HTTP 200 OK, but got {response.status_code}"

    # Parse the JSON response
    data = response.json()

    # Assert that the response contains the 'agents' key
    assert "agents" in data, "Response JSON must contain an 'agents' key"

    # Assert that the 'agents' key's value is a list
    assert isinstance(data["agents"], list), "The value of 'agents' must be a list"

    # Assert that the list of agents is not empty
    # This directly checks that the count of registered agents is not null (zero).
    assert len(data["agents"]) > 0, "The list of registered agents should not be empty."

    # You could optionally add more specific checks here if you know the exact
    # expected count, e.g.:
    # assert len(data["agents"]) == 2, "Expected exactly 2 registered agents based on mock setup"

def test_active_agent_count_not_null(client, mocker):
    """
    Tests that the /get_active_agents_count endpoint returns a non-zero count
    of active agents, ensuring the count is not null (or zero).
    """
    # 1. Mock the system.get_active_agents_count method
    # We'll make it return a specific non-zero count for this test.
    mock_get_active_agents_count = mocker.patch(
        'fastapi_endpoint.system.get_active_agents_count',
        return_value=3 # Assuming 3 active agents for this test scenario
    )

    # 2. Make a GET request to the new /get_active_agents_count endpoint
    response = client.get("/get_active_agents_count")

    # 3. Assert that the API call was successful
    assert response.status_code == 200, f"Expected HTTP 200 OK, but got {response.status_code}"

    # 4. Parse the JSON response
    data = response.json()

    # 5. Assert that the mocked method was called exactly once
    #mock_get_active_agents_count.assert_called_once()

    # 6. Assert that the response contains the 'active_agents_count' key
    assert "active_agents_count" in data, "Response JSON must contain an 'active_agents_count' key"

    # 7. Assert that the count is an integer
    assert isinstance(data["active_agents_count"], int), "The 'active_agents_count' should be an integer"

    # 8. Assert that the active agent count is NOT null (i.e., greater than 0)
    assert data["active_agents_count"] > 0, "The count of active agents should be greater than 0"

    # 9. Assert that the count matches the mocked return value
    assert data["active_agents_count"] == 3, "The active agent count should match the mocked value"
