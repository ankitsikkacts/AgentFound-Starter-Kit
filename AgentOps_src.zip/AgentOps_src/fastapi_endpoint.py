from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
import json
import uuid
import logging
from typing import Dict
from BaseAgent import BaseCoordinator, BaseAgent
from RegistrationAgent import RegistrationAgent
from LoggingMetricAgent import LoggingMetricAgent
from pydantic import BaseModel
from config import get_aws_credentials

"""Example usage of the LangGraph multiagent system"""

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CoordinatorAgent(BaseCoordinator):
    """Coordinator agent that manages different specialized agents"""
    
    def _initialize_agents(self) -> Dict[str, BaseAgent]:
        """Initialize all available agents"""
        return {
            "registration": RegistrationAgent(self.aws_access_key_id, self.aws_secret_access_key, self.region_name),
            "logging_token_metric": LoggingMetricAgent(self.aws_access_key_id, self.aws_secret_access_key, self.region_name)
        }

class MultiAgentSystem:
    """Main multiagent system using LangGraph"""
    
    def __init__(self, aws_access_key_id: str, aws_secret_access_key: str, region_name: str = 'us-east-1'):
        self.coordinator = CoordinatorAgent(aws_access_key_id, aws_secret_access_key, region_name)
        logger.info("MultiAgent system initialized with LangGraph")
    
    def process_request(self, user_input: str, thread_id: str = "default") -> str:
        """Process a user request"""
        return self.coordinator.process_request(user_input, thread_id)
    
    def list_agents(self) -> Dict[str, str]:
        """List all available agents"""
        return self.coordinator.list_agents()
    
    def get_conversation_history(self, agent_type: str = "math", thread_id: str = "default") -> list:
        """Get conversation history"""
        return self.coordinator.get_agent_conversation_history(agent_type, thread_id)

# Define the request model
class QueryRequest(BaseModel):
    query: str
    config_name: str = "config_server"  # Default config name

# Dictionary to store agent systems with different configs
agent_systems = {}

def get_or_create_system(config_name: str) -> MultiAgentSystem:
    """Get or create a MultiAgentSystem with the specified config"""
    if config_name not in agent_systems:
        # Load AWS credentials from the specified config
        aws_creds = get_aws_credentials(config_name)
        
        # Create a new system with these credentials
        agent_systems[config_name] = MultiAgentSystem(
            aws_access_key_id=aws_creds["aws_access_key_id"],
            aws_secret_access_key=aws_creds["aws_secret_access_key"],
            region_name=aws_creds["region_name"]
        )
        logger.info(f"Created new agent system with config: {config_name}")
    
    return agent_systems[config_name]

app = FastAPI()

# List of allowed origins
origins = [
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:8501",
    "http://localhost:8502",
    "http://localhost:8503",
    "http://localhost:8504",
    "https://localhost:9000",
    "https://d3vk1opd9ea861.cloudfront.net"
]

# Adding CORS middleware to the FastAPI application
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/call_agentOps_agent")
def trigger_agent_call(request: QueryRequest):
    try:
        # Get the appropriate system based on config_name
        system = get_or_create_system(request.config_name)
        
        # Generate a thread ID
        thread_id = str(uuid.uuid4())
        logger.info(f"Processing request with thread ID: {thread_id}, config: {request.config_name}")
        logger.info(f"Request query: {request.query}")
        
        # Process the request
        response = system.process_request(request.query, thread_id)
        
        try:
            parsed_response = json.loads(response)
            logger.info(f"Successfully processed request: {thread_id}")
            return parsed_response
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON response: {response}")
            return {"error": "Invalid response format", "raw_response": response}
            
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return {"error": str(e)}