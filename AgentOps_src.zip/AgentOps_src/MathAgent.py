"""
Math Agent implementation with mathematical calculation capabilities.
Contains math-specific tools and agent logic.
"""

import logging
from typing import List
from langchain_core.tools import tool
from BaseAgent import BaseAgent

# Configure logging
logger = logging.getLogger(__name__)

# Mathematical tools
@tool
def sum_numbers(a: float, b: float) -> float:
    """Calculate the sum of two numbers.
    Args:
        a: First number
        b: Second number
    Returns:
        The sum of a and b
    """
    result = a + b
    logger.info(f"Sum tool executed: {a} + {b} = {result}")
    return result

@tool
def product_numbers(a: float, b: float) -> float:
    """Calculate the product of two numbers.
    Args:
        a: First number
        b: Second number
    Returns:
        The product of a and b
    """
    result = a * b
    logger.info(f"Product tool executed: {a} * {b} = {result}")
    return result

class MathAgent(BaseAgent):
    """Math agent with mathematical calculation capabilities"""
    
    def _get_tools(self) -> List:
        """Return math-specific tools"""
        return [
            sum_numbers, 
            product_numbers
        ]
    
    def _get_system_message(self) -> str:
        """Return math-specific system message"""
        return """You are a mathematical assistant with access to mathematical tools.
        Available tools:
        - sum_numbers(a, b): Calculate the sum of two numbers
        - product_numbers(a, b): Calculate the product of two numbers
        
        When users ask for mathematical calculations, use the appropriate tools to provide accurate results.
        Always explain your reasoning and show the calculations clearly.
        For complex calculations involving multiple operations, break them down step by step.
        """
    
    def get_agent_description(self) -> str:
        """Return description of math agent capabilities"""
        return "Mathematical operations agent with arithmetic tools (addition, subtraction, multiplication, division, power)"
