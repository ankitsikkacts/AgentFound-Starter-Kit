from pymongo import MongoClient
from bson.objectid import ObjectId

# Establish connection to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client['agent_db']
collection = db['agents']

# --- Step 1: Dynamically fetch an ObjectId from the database ---
# We'll try to find any one document and get its _id.
# If the collection is empty, this step won't work, so we'll handle that.
fetched_document_id = None
try:
    # Find one document (e.g., the first one encountered)
    # You could add a filter here if you want a specific type of document, e.g., {"name": "SomeAgent"}
    first_document = collection.find_one({})
    if first_document:
        fetched_document_id = first_document['_id']
        print(f"\nSuccessfully fetched an _id from the database: {fetched_document_id}")
    else:
        print("\nNo documents found in 'agents' collection. Cannot proceed with fetching an _id.")
        print("Please ensure your 'agents' collection has at least one document.")

except Exception as e:
    print(f"\nError fetching an _id: {e}")
    # Handle connection error at this stage as well
    print("Please ensure MongoDB is running and accessible.")

# --- Step 2: Use the fetched ObjectId to check database connectivity and retrieve the document ---
if fetched_document_id:
    print(f"\nAttempting to retrieve document using fetched _id: {fetched_document_id}")
    # Retrieve the document using find_one() with the fetched _id
    try:
        retrieved_document = collection.find_one({"_id": fetched_document_id})

        if retrieved_document:
            print("\nSuccessfully retrieved the document using the dynamically fetched _id:")
            # Use 'str()' to ensure ObjectId is printed nicely if you're not using a custom formatter
            print(retrieved_document)
        else:
            print(f"\nError: The document with _id {fetched_document_id} could not be retrieved.")

    except Exception as e:
        print(f"\nError during second retrieval attempt: {e}")
        print("This might indicate a connection issue or an invalid _id.")
else:
    print("\nSkipping second retrieval attempt as no _id was fetched.")

# Close the MongoDB connection
client.close()
print("\nMongoDB connection closed.")
